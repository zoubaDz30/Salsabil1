package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.ParentDashboardScreen
import com.example.ui.screens.WelcomeScreen
import com.example.ui.theme.MyApplicationTheme

enum class ScreenState {
  WELCOME,
  AUTH,
  PARENT_DASHBOARD
}

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        // Enforce RTL Layout for Arabic display, typography and proper alignment
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
          var currentScreen by remember { mutableStateOf(ScreenState.WELCOME) }

          BackHandler(enabled = currentScreen != ScreenState.WELCOME) {
            currentScreen = when (currentScreen) {
              ScreenState.PARENT_DASHBOARD -> ScreenState.AUTH
              ScreenState.AUTH -> ScreenState.WELCOME
              ScreenState.WELCOME -> ScreenState.WELCOME
            }
          }

          // Main App Navigation Container
          Surface(modifier = Modifier.fillMaxSize()) {
            when (currentScreen) {
              ScreenState.WELCOME -> {
                WelcomeScreen(
                  onEnterClicked = { currentScreen = ScreenState.AUTH }
                )
              }
              ScreenState.AUTH -> {
                AuthScreen(
                  onBackToWelcome = { currentScreen = ScreenState.WELCOME },
                  onParentLoginSuccess = { currentScreen = ScreenState.PARENT_DASHBOARD },
                  onAdminLoginSuccess = { /* Reserved */ }
                )
              }
              ScreenState.PARENT_DASHBOARD -> {
                ParentDashboardScreen(
                  onLogout = { currentScreen = ScreenState.WELCOME },
                  onOpenSettings = { /* Reserved */ }
                )
              }
            }
          }
        }
      }
    }
  }
}
