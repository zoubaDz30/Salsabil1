package com.example.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.UnfoldLess
import androidx.compose.material.icons.filled.UnfoldMore
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.model.BloodGroupList
import com.example.data.model.ChildRegistration
import com.example.data.model.EducationalLevels
import com.example.data.model.FamilyRelations
import com.example.ui.theme.DarkText
import com.example.ui.theme.JoyPink
import com.example.ui.theme.JoyPinkDark
import com.example.ui.theme.MutedText
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SalsabeelBlue
import com.example.ui.theme.SalsabeelBlueDark
import com.example.ui.theme.SproutGreen
import com.example.ui.theme.SproutGreenDark
import com.example.util.PdfRegistrationExporter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.viewmodel.DashboardViewModel

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ChildRegistrationScreen(
  onNavigateBack: () -> Unit = {},
  initialRegistration: ChildRegistration? = null,
  viewModel: DashboardViewModel = viewModel()
) {
  val context = LocalContext.current
  val todayFormatted = remember {
    SimpleDateFormat("dd / MM / yyyy", Locale.getDefault()).format(Date())
  }

  // Registration data
  var registrationData by remember {
    mutableStateOf(
      initialRegistration ?: ChildRegistration(
        registrationDate = todayFormatted
      )
    )
  }

  // If we are editing, we might want some sections expanded
  val isEditing = initialRegistration != null

  // Expansion states for each section - closed by default as requested
  var isP4Expanded by remember { mutableStateOf(false) } // Child info
  var isP5Expanded by remember { mutableStateOf(false) } // Parents info
  var isP7Expanded by remember { mutableStateOf(false) } // Emergency info
  var isP9Expanded by remember { mutableStateOf(false) } // Health info
  var isPp10Expanded by remember { mutableStateOf(false) } // Notes & Signature

  var siblingCount by remember { mutableStateOf(1) }
  var showSuccessDialog by remember { mutableStateOf(false) }

  // Sibling registration handler (keeps parents info, resets child info)
  val registerAnotherChild: () -> Unit = {
    siblingCount += 1
    registrationData = ChildRegistration(
      // Keep Parents Info
      fatherName = registrationData.fatherName,
      fatherPhone = registrationData.fatherPhone,
      motherName = registrationData.motherName,
      motherPhone = registrationData.motherPhone,
      idCardPhotoUri = registrationData.idCardPhotoUri,
      // Keep Home Address
      homeAddress = registrationData.homeAddress,
      // Keep Emergency Contact
      emergencyContactName = registrationData.emergencyContactName,
      emergencyContactRelation = registrationData.emergencyContactRelation,
      emergencyContactPhone = registrationData.emergencyContactPhone,
      // Keep Guardian Name and Date
      guardianName = registrationData.guardianName.ifBlank { registrationData.fatherName },
      registrationDate = todayFormatted,
      // Reset Child Info
      childFullName = "",
      gender = "ذكر",
      birthDateAndPlace = "",
      age = "",
      educationalLevel = "أصاغر (2-3 سنوات)",
      childPhotoUri = null,
      // Reset Health Info
      hasChronicDisease = false,
      chronicDiseaseDetails = "",
      hasAllergy = false,
      allergyDetails = "",
      takesRegularMedicine = false,
      medicineDetails = "",
      hasFoodAllergy = false,
      foodAllergyDetails = "",
      hadSeizures = false,
      seizuresDetails = "",
      bloodGroup = "غير معروفة",
      otherHealthNotes = "",
      guardianSignature = "",
      isSubmittedToAdmin = false
    )
    // Open Child Info card directly
    isP4Expanded = true
    isP5Expanded = false
    isP7Expanded = false
    isP9Expanded = false
    isPp10Expanded = false
    Toast.makeText(
      context,
      "تم الاحتفاظ بمعلومات الوالدين والعائلة بنجاح! يمكنك الآن إدخال بيانات الطفل الجديد 👶",
      Toast.LENGTH_LONG
    ).show()
  }

  // Photo pickers
  val childPhotoPicker = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.PickVisualMedia()
  ) { uri: Uri? ->
    if (uri != null) {
      registrationData = registrationData.copy(childPhotoUri = uri)
    }
  }

  val idCardPicker = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.PickVisualMedia()
  ) { uri: Uri? ->
    if (uri != null) {
      registrationData = registrationData.copy(idCardPhotoUri = uri)
    }
  }

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Text(
            text = "استمارة معلومات الطفل 📝",
            fontSize = 17.sp,
            fontWeight = FontWeight.Bold,
            color = SalsabeelBlueDark
          )
        },
        navigationIcon = {
          IconButton(onClick = onNavigateBack) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.ArrowBack,
              contentDescription = "رجوع",
              tint = SalsabeelBlueDark
            )
          }
        },
        actions = {
          // Toggle all expand/collapse
          val allExpanded = isP4Expanded && isP5Expanded && isP7Expanded && isP9Expanded && isPp10Expanded
          TextButton(
            onClick = {
              val target = !allExpanded
              isP4Expanded = target
              isP5Expanded = target
              isP7Expanded = target
              isP9Expanded = target
              isPp10Expanded = target
            }
          ) {
            Icon(
              imageVector = if (allExpanded) Icons.Default.UnfoldLess else Icons.Default.UnfoldMore,
              contentDescription = null,
              modifier = Modifier.size(18.dp),
              tint = SalsabeelBlue
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = if (allExpanded) "طي الكل" else "فتح الكل",
              fontSize = 12.sp,
              color = SalsabeelBlue,
              fontWeight = FontWeight.Bold
            )
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = PureWhite)
      )
    },
    containerColor = Color(0xFFF8FAFC)
  ) { paddingValues ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(paddingValues)
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 14.dp, vertical = 10.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {

      // Quick Banner for Sibling Registration - ONLY show after submission
      if (registrationData.isSubmittedToAdmin) {
        Surface(
          shape = RoundedCornerShape(16.dp),
          color = Color(0xFFEFF6FF),
          border = BorderStroke(1.dp, Color(0xFFBFDBFE)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  imageVector = Icons.Default.PersonAdd,
                  contentDescription = null,
                  tint = SalsabeelBlue,
                  modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = if (siblingCount > 1) "تسجيل الطفل رقم $siblingCount (أخ/أخت) 👶" else "تسجيل إخوة في نفس العائلة 👶",
                  fontSize = 13.sp,
                  fontWeight = FontWeight.Bold,
                  color = SalsabeelBlueDark
                )
              }
              Spacer(modifier = Modifier.height(2.dp))
              Text(
                text = "يتم الاحتفاظ ببيانات الوالدين والعائلة تلقائياً دون إعادة إدخالها",
                fontSize = 11.sp,
                color = MutedText
              )
            }

            Spacer(modifier = Modifier.width(8.dp))

            Button(
              onClick = registerAnotherChild,
              shape = RoundedCornerShape(10.dp),
              colors = ButtonDefaults.buttonColors(containerColor = SalsabeelBlue),
              contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 6.dp)
            ) {
              Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(15.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("إضافة طفل آخر", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
            }
          }
        }
      }

      // ======================================================================
      // 1. صورة P1: شريط ترحيبي عريض (معاً من أجل طفل آمن وسليم)
      // ======================================================================
      AccordionImageCard(
        imageRes = R.drawable.p1,
        contentDescription = "معاً من أجل طفل آمن وسليم",
        backgroundColor = Color(0xFFFFF1F2),
        borderColor = Color(0xFFFECDD3),
        imageHeight = 72.dp
      )

      // ======================================================================
      // 2. صورة P2: لوحة أطفال الروضة مع الكتب المدرسية
      // ======================================================================
      AccordionImageCard(
        imageRes = R.drawable.p2,
        contentDescription = "أطفال روضة السلسبيل - مكان آمن لطفل مبدع",
        backgroundColor = Color(0xFFF8FAFC),
        borderColor = Color(0xFFE2E8F0),
        imageHeight = 160.dp
      )

      // ======================================================================
      // 3. صورة P3: شريط الزهور (معاً من أجل مستقبل أفضل لأطفالنا)
      // ======================================================================
      AccordionImageCard(
        imageRes = R.drawable.p3,
        contentDescription = "معاً من أجل مستقبل أفضل لأطفالنا",
        backgroundColor = Color(0xFFFDF2F8),
        borderColor = Color(0xFFFBCFE8),
        imageHeight = 72.dp
      )

      // ======================================================================
      // 4. صورة P4: شريط (معلومات الطفل - أزرق) [قابل للتوسيع]
      // ======================================================================
      ExpandableSectionCard(
        imageRes = R.drawable.p4,
        contentDescription = "معلومات الطفل",
        backgroundColor = Color(0xFFF0F9FF),
        borderColor = Color(0xFFBAE6FD),
        ribbonHeight = 64.dp,
        isExpanded = isP4Expanded,
        onToggleExpand = { isP4Expanded = !isP4Expanded },
        badgeText = "معلومات الطفل"
      ) {
        // Child Photo Box
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(PureWhite)
            .border(1.dp, Color(0xFFBAE6FD), RoundedCornerShape(14.dp))
            .padding(10.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Box(
            modifier = Modifier
              .size(62.dp)
              .clip(CircleShape)
              .background(Color(0xFFE0F2FE))
              .border(2.dp, SalsabeelBlue, CircleShape),
            contentAlignment = Alignment.Center
          ) {
            if (registrationData.childPhotoUri != null) {
              AsyncImage(
                model = registrationData.childPhotoUri,
                contentDescription = "صورة الطفل",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
              )
            } else {
              Icon(Icons.Default.Person, contentDescription = null, tint = SalsabeelBlue, modifier = Modifier.size(34.dp))
            }
          }

          Spacer(modifier = Modifier.width(12.dp))

          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = if (registrationData.childPhotoUri != null) "تم إرفاق صورة الطفل بنجاح ✨" else "صورة الطفل الشخصية 📷",
              fontSize = 13.sp,
              fontWeight = FontWeight.Bold,
              color = DarkText
            )
            Text(text = "خانة صورة الطفل في الاستمارة الرسمية", fontSize = 11.sp, color = MutedText)
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedButton(
              onClick = {
                childPhotoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
              },
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.height(34.dp)
            ) {
              Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(14.dp), tint = SalsabeelBlue)
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = if (registrationData.childPhotoUri != null) "تغيير الصورة" else "إضافة صورة الطفل",
                fontSize = 11.sp,
                color = SalsabeelBlue
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        BrochureFormField(
          label = "اسم ولقب الطفل:",
          value = registrationData.childFullName,
          onValueChange = { registrationData = registrationData.copy(childFullName = it) },
          placeholder = "الاسم واللقب كما في الدفتر العائلي"
        )

        // Child Gender Selection
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(PureWhite)
            .border(1.dp, Color(0xFFBAE6FD), RoundedCornerShape(12.dp))
            .padding(10.dp)
        ) {
          Text(
            text = "جنس الطفل:",
            fontSize = 12.5.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF334155)
          )
          Spacer(modifier = Modifier.height(6.dp))
          Row(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            // Boy option
            val isBoy = registrationData.gender == "ذكر"
            Surface(
              shape = RoundedCornerShape(10.dp),
              color = if (isBoy) SalsabeelBlue else Color(0xFFF1F5F9),
              border = BorderStroke(1.dp, if (isBoy) SalsabeelBlue else Color(0xFFCBD5E1)),
              modifier = Modifier
                .weight(1f)
                .clickable { registrationData = registrationData.copy(gender = "ذكر") }
            ) {
              Row(
                modifier = Modifier.padding(vertical = 10.dp, horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
              ) {
                Text(
                  text = "👦 ذكر",
                  fontSize = 13.sp,
                  fontWeight = if (isBoy) FontWeight.Bold else FontWeight.Normal,
                  color = if (isBoy) PureWhite else DarkText
                )
              }
            }

            // Girl option
            val isGirl = registrationData.gender == "أنثى"
            Surface(
              shape = RoundedCornerShape(10.dp),
              color = if (isGirl) JoyPink else Color(0xFFF1F5F9),
              border = BorderStroke(1.dp, if (isGirl) JoyPink else Color(0xFFCBD5E1)),
              modifier = Modifier
                .weight(1f)
                .clickable { registrationData = registrationData.copy(gender = "أنثى") }
            ) {
              Row(
                modifier = Modifier.padding(vertical = 10.dp, horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
              ) {
                Text(
                  text = "👧 أنثى",
                  fontSize = 13.sp,
                  fontWeight = if (isGirl) FontWeight.Bold else FontWeight.Normal,
                  color = if (isGirl) PureWhite else DarkText
                )
              }
            }
          }
        }

        BrochureFormField(
          label = "تاريخ ومكان الميلاد:",
          value = registrationData.birthDateAndPlace,
          onValueChange = { registrationData = registrationData.copy(birthDateAndPlace = it) },
          placeholder = "مثال: 15 / 03 / 2022 - ورقلة"
        )

        BrochureFormField(
          label = "العمر:",
          value = registrationData.age,
          onValueChange = { registrationData = registrationData.copy(age = it) },
          placeholder = "مثال: 3 سنوات ونصف"
        )

        // Educational Level Interactive Chips (Option 3)
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(PureWhite)
            .border(1.dp, Color(0xFFBAE6FD), RoundedCornerShape(12.dp))
            .padding(12.dp)
        ) {
          Text(
            text = "المستوى الدراسي:",
            fontSize = 12.5.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF334155)
          )
          Spacer(modifier = Modifier.height(8.dp))
          FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            EducationalLevels.forEach { level ->
              val isSelected = registrationData.educationalLevel == level
              val chipColor = when {
                level.contains("أصاغر") -> Color(0xFF10B981)
                level.contains("تمهيدي") -> SalsabeelBlue
                else -> Color(0xFF8B5CF6)
              }
              FilterChip(
                selected = isSelected,
                onClick = {
                  registrationData = registrationData.copy(educationalLevel = level)
                },
                leadingIcon = if (isSelected) {
                  {
                    Icon(
                      imageVector = Icons.Default.Check,
                      contentDescription = null,
                      tint = PureWhite,
                      modifier = Modifier.size(16.dp)
                    )
                  }
                } else null,
                label = {
                  Text(
                    text = level,
                    fontSize = 12.5.sp,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                  )
                },
                colors = FilterChipDefaults.filterChipColors(
                  selectedContainerColor = chipColor,
                  selectedLabelColor = PureWhite,
                  containerColor = Color(0xFFF8FAFC),
                  labelColor = DarkText
                ),
                border = BorderStroke(
                  width = if (isSelected) 1.5.dp else 1.dp,
                  color = if (isSelected) chipColor else Color(0xFFE2E8F0)
                ),
                shape = RoundedCornerShape(10.dp)
              )
            }
          }
        }

        BrochureFormField(
          label = "العنوان:",
          value = registrationData.homeAddress,
          onValueChange = { registrationData = registrationData.copy(homeAddress = it) },
          placeholder = "عنوان الإقامة الحالي"
        )
      }

      // ======================================================================
      // 5. صورة P5: شريط (معلومات الوالدين - بنفسجي) [قابل للتوسيع]
      // ======================================================================
      ExpandableSectionCard(
        imageRes = R.drawable.p5,
        contentDescription = "معلومات الوالدين",
        backgroundColor = Color(0xFFF5F3FF),
        borderColor = Color(0xFFDDD6FE),
        ribbonHeight = 64.dp,
        isExpanded = isP5Expanded,
        onToggleExpand = { isP5Expanded = !isP5Expanded },
        badgeText = "معلومات الوالدين"
      ) {
        BrochureFormField(
          label = "اسم ولقب الأب:",
          value = registrationData.fatherName,
          onValueChange = { registrationData = registrationData.copy(fatherName = it) },
          placeholder = "الاسم الكامل للأب"
        )

        BrochureFormField(
          label = "رقم هاتف الأب:",
          value = registrationData.fatherPhone,
          onValueChange = { registrationData = registrationData.copy(fatherPhone = it) },
          placeholder = "06XXXXXXXX",
          keyboardType = KeyboardType.Phone
        )

        BrochureFormField(
          label = "اسم ولقب الأم:",
          value = registrationData.motherName,
          onValueChange = { registrationData = registrationData.copy(motherName = it) },
          placeholder = "الاسم الكامل للأم"
        )

        BrochureFormField(
          label = "رقم هاتف الأم:",
          value = registrationData.motherPhone,
          onValueChange = { registrationData = registrationData.copy(motherPhone = it) },
          placeholder = "07XXXXXXXX",
          keyboardType = KeyboardType.Phone
        )

        Spacer(modifier = Modifier.height(6.dp))

        // Guardian ID Card Upload
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(PureWhite)
            .border(1.dp, Color(0xFFDDD6FE), RoundedCornerShape(14.dp))
            .padding(10.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Box(
            modifier = Modifier
              .size(50.dp)
              .clip(RoundedCornerShape(8.dp))
              .background(Color(0xFFEDE9FE))
              .border(1.5.dp, Color(0xFF8B5CF6), RoundedCornerShape(8.dp)),
            contentAlignment = Alignment.Center
          ) {
            if (registrationData.idCardPhotoUri != null) {
              AsyncImage(
                model = registrationData.idCardPhotoUri,
                contentDescription = "بطاقة التعريف",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
              )
            } else {
              Icon(Icons.Default.Badge, contentDescription = null, tint = Color(0xFF8B5CF6), modifier = Modifier.size(28.dp))
            }
          }

          Spacer(modifier = Modifier.width(12.dp))

          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = if (registrationData.idCardPhotoUri != null) "تم إرفاق بطاقة التعريف 🪪" else "بطاقة التعريف الوطنية لولي الأمر",
              fontSize = 12.5.sp,
              fontWeight = FontWeight.Bold,
              color = DarkText
            )
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedButton(
              onClick = {
                idCardPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
              },
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.height(32.dp)
            ) {
              Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(13.dp), tint = Color(0xFF8B5CF6))
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = if (registrationData.idCardPhotoUri != null) "تغيير البطاقة" else "إرفاق بطاقة الهوية 🪪",
                fontSize = 11.sp,
                color = Color(0xFF8B5CF6)
              )
            }
          }
        }
      }

      // ======================================================================
      // 6. صورة P6: شريط السحاب (استمارة معلومات الطفل)
      // ======================================================================
      AccordionImageCard(
        imageRes = R.drawable.p6,
        contentDescription = "استمارة معلومات الطفل",
        backgroundColor = Color(0xFFECFEFF),
        borderColor = Color(0xFFA5F3FC),
        imageHeight = 78.dp
      )

      // ======================================================================
      // 7. صورة P7: شريط (شخص من العائلة للتواصل عند الضرورة - أخضر) [قابل للتوسيع]
      // ======================================================================
      ExpandableSectionCard(
        imageRes = R.drawable.p7,
        contentDescription = "شخص من العائلة للتواصل عند الضرورة",
        backgroundColor = Color(0xFFF0FDF4),
        borderColor = Color(0xFFBBF7D0),
        ribbonHeight = 64.dp,
        isExpanded = isP7Expanded,
        onToggleExpand = { isP7Expanded = !isP7Expanded },
        badgeText = "شخص للطوارئ"
      ) {
        BrochureFormField(
          label = "اسم ولقب فرد من العائلة:",
          value = registrationData.emergencyContactName,
          onValueChange = { registrationData = registrationData.copy(emergencyContactName = it) },
          placeholder = "الاسم واللقب الكامل"
        )

        // Relation Dropdown
        var expandedRelation by remember { mutableStateOf(false) }
        ExposedDropdownMenuBox(
          expanded = expandedRelation,
          onExpandedChange = { expandedRelation = !expandedRelation },
          modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
        ) {
          OutlinedTextField(
            value = registrationData.emergencyContactRelation,
            onValueChange = {},
            readOnly = true,
            label = { Text("صلة القرابة:", fontSize = 13.sp, fontWeight = FontWeight.Bold) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedRelation) },
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
              unfocusedContainerColor = PureWhite,
              focusedContainerColor = PureWhite
            ),
            modifier = Modifier
              .menuAnchor(MenuAnchorType.PrimaryNotEditable)
              .fillMaxWidth()
          )
          ExposedDropdownMenu(
            expanded = expandedRelation,
            onDismissRequest = { expandedRelation = false }
          ) {
            FamilyRelations.forEach { rel ->
              DropdownMenuItem(
                text = { Text(rel, fontSize = 13.sp) },
                onClick = {
                  registrationData = registrationData.copy(emergencyContactRelation = rel)
                  expandedRelation = false
                }
              )
            }
          }
        }

        BrochureFormField(
          label = "رقم الهاتف:",
          value = registrationData.emergencyContactPhone,
          onValueChange = { registrationData = registrationData.copy(emergencyContactPhone = it) },
          placeholder = "06XXXXXXXX للتواصل عند الطوارئ",
          keyboardType = KeyboardType.Phone
        )
      }

      // ======================================================================
      // 8. صورة P8: لوحة المنزل والحديقة (تعاونكم معنا يساعدنا على رعاية أطفالكم بأفضل شكل)
      // ======================================================================
      AccordionImageCard(
        imageRes = R.drawable.p8,
        contentDescription = "تعاونكم معنا يساعدنا على رعاية أطفالكم بأفضل شكل",
        backgroundColor = Color(0xFFF7FEE7),
        borderColor = Color(0xFFD9F99D),
        imageHeight = 220.dp
      )

      // ======================================================================
      // 9. صورة P9: شريط (المعلومات الصحية للطفل - وردي/أحمر) [قابل للتوسيع]
      // ======================================================================
      ExpandableSectionCard(
        imageRes = R.drawable.p9,
        contentDescription = "المعلومات الصحية للطفل",
        backgroundColor = Color(0xFFFFF1F2),
        borderColor = Color(0xFFFECDD3),
        ribbonHeight = 64.dp,
        isExpanded = isP9Expanded,
        onToggleExpand = { isP9Expanded = !isP9Expanded },
        badgeText = "الملف الصحي"
      ) {
        BrochureHealthQuestion(
          question = "هل يعاني الطفل من أي مرض مزمن؟",
          isYes = registrationData.hasChronicDisease,
          details = registrationData.chronicDiseaseDetails,
          detailsPrompt = "إذا كانت الإجابة نعم، يرجى التوضيح:",
          onToggle = { registrationData = registrationData.copy(hasChronicDisease = it) },
          onDetailsChange = { registrationData = registrationData.copy(chronicDiseaseDetails = it) }
        )

        BrochureHealthQuestion(
          question = "هل يعاني الطفل من أي نوع من الحساسية؟",
          isYes = registrationData.hasAllergy,
          details = registrationData.allergyDetails,
          detailsPrompt = "إذا نعم، ما نوع الحساسية؟",
          onToggle = { registrationData = registrationData.copy(hasAllergy = it) },
          onDetailsChange = { registrationData = registrationData.copy(allergyDetails = it) }
        )

        BrochureHealthQuestion(
          question = "هل يتناول الطفل أي دواء بانتظام؟",
          isYes = registrationData.takesRegularMedicine,
          details = registrationData.medicineDetails,
          detailsPrompt = "إذا نعم، اذكر اسم الدواء والسبب:",
          onToggle = { registrationData = registrationData.copy(takesRegularMedicine = it) },
          onDetailsChange = { registrationData = registrationData.copy(medicineDetails = it) }
        )

        BrochureHealthQuestion(
          question = "هل لديه حساسية تجاه أطعمة معينة؟",
          isYes = registrationData.hasFoodAllergy,
          details = registrationData.foodAllergyDetails,
          detailsPrompt = "إذا نعم، اذكرها:",
          onToggle = { registrationData = registrationData.copy(hasFoodAllergy = it) },
          onDetailsChange = { registrationData = registrationData.copy(foodAllergyDetails = it) }
        )

        BrochureHealthQuestion(
          question = "هل سبق أن تعرض الطفل لتشنجات أو نوبات صحية؟",
          isYes = registrationData.hadSeizures,
          details = registrationData.seizuresDetails,
          detailsPrompt = "إذا نعم، يرجى التوضيح:",
          onToggle = { registrationData = registrationData.copy(hadSeizures = it) },
          onDetailsChange = { registrationData = registrationData.copy(seizuresDetails = it) }
        )

        Spacer(modifier = Modifier.height(6.dp))

        // Blood Group selector
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(PureWhite)
            .border(1.dp, Color(0xFFFECDD3), RoundedCornerShape(12.dp))
            .padding(10.dp)
        ) {
          Text(
            text = "فصيلة الدم (إن كانت معروفة):",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF9F1239)
          )
          Spacer(modifier = Modifier.height(6.dp))
          OptInFlowRow(
            bloodGroups = BloodGroupList,
            selectedGroup = registrationData.bloodGroup,
            onSelect = { registrationData = registrationData.copy(bloodGroup = it) }
          )
        }

        Spacer(modifier = Modifier.height(6.dp))

        BrochureFormField(
          label = "معلومات صحية أخرى نرى ضرورة إبلاغ الإدارة بها:",
          value = registrationData.otherHealthNotes,
          onValueChange = { registrationData = registrationData.copy(otherHealthNotes = it) },
          placeholder = "أي ملاحظات إضافية بخصوص صحة الطفل...",
          minLines = 2
        )
      }

      // ======================================================================
      // 10. صورة PP10: شريط (ملاحظات مهمة - أصفر/عسلي) [قابل للتوسيع]
      // ======================================================================
      ExpandableSectionCard(
        imageRes = R.drawable.pp10,
        contentDescription = "ملاحظات مهمة",
        backgroundColor = Color(0xFFFEFCE8),
        borderColor = Color(0xFFFEF08A),
        ribbonHeight = 64.dp,
        isExpanded = isPp10Expanded,
        onToggleExpand = { isPp10Expanded = !isPp10Expanded },
        badgeText = "ملاحظات وإمضاء"
      ) {
        Surface(
          shape = RoundedCornerShape(12.dp),
          color = PureWhite,
          border = BorderStroke(1.dp, Color(0xFFFEF08A)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Text(
            text = "يرجى من ولي الأمر إبلاغ إدارة الروضة بأي معلومة صحية أو خاصة بالطفل قد تساعدنا على ضمان سلامته وحسن التكفل به.",
            fontSize = 12.sp,
            color = Color(0xFF854D0E),
            lineHeight = 19.sp,
            modifier = Modifier.padding(12.dp)
          )
        }

        Spacer(modifier = Modifier.height(10.dp))

        BrochureFormField(
          label = "اسم ولي الأمر:",
          value = registrationData.guardianName.ifBlank { registrationData.fatherName },
          onValueChange = { registrationData = registrationData.copy(guardianName = it) },
          placeholder = "الاسم الكامل لولي الأمر"
        )

        BrochureFormField(
          label = "الإمضاء:",
          value = registrationData.guardianSignature,
          onValueChange = { registrationData = registrationData.copy(guardianSignature = it) },
          placeholder = "اكتب توقيعك أو اسمك للاعتماد الإلكتروني"
        )

        BrochureFormField(
          label = "التاريخ:",
          value = registrationData.registrationDate,
          onValueChange = { registrationData = registrationData.copy(registrationDate = it) },
          placeholder = "اليوم"
        )
      }

      // ======================================================================
      // 11. صورة PP11: شريط الختام (معلومات الطفل و الوالدين) + أزرار العمليات
      // ======================================================================
      Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFDF2F8)),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
        border = BorderStroke(1.5.dp, Color(0xFFFBCFE8)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Image(
            painter = painterResource(id = R.drawable.pp11),
            contentDescription = "معلومات الطفل والوالدين",
            contentScale = ContentScale.Fit,
            modifier = Modifier
              .fillMaxWidth()
              .height(68.dp)
          )

          Spacer(modifier = Modifier.height(14.dp))

          Text(
            text = "اكتملت جميع أقسام الاستمارة الرسمية بنجاح ✨",
            fontSize = 13.5.sp,
            fontWeight = FontWeight.Bold,
            color = JoyPinkDark,
            textAlign = TextAlign.Center
          )

          Spacer(modifier = Modifier.height(16.dp))

          // Download PDF Button
          Button(
            onClick = {
              PdfRegistrationExporter.generateAndSharePdf(context, registrationData)
            },
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = SalsabeelBlue),
            modifier = Modifier
              .fillMaxWidth()
              .height(48.dp)
              .testTag("download_pdf_btn")
          ) {
            Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(19.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("تحميل الاستمارة بصيغة PDF 📄", fontSize = 14.sp, fontWeight = FontWeight.Bold)
          }

          Spacer(modifier = Modifier.height(10.dp))

          // Submit to Admin Button
          Button(
            onClick = {
              viewModel.submitRegistration(registrationData)
              showSuccessDialog = true
            },
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = SproutGreenDark),
            modifier = Modifier
              .fillMaxWidth()
              .height(48.dp)
              .testTag("submit_to_admin_btn")
          ) {
            Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(19.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("إرسال الاستمارة إلى إدارة الروضة 📤", fontSize = 14.sp, fontWeight = FontWeight.Bold)
          }
        }
      }

      Spacer(modifier = Modifier.height(20.dp))
    }
  }

  // Submission Dialog
  if (showSuccessDialog) {
    AlertDialog(
      onDismissRequest = { showSuccessDialog = false },
      icon = {
        Icon(
          imageVector = Icons.Default.CheckCircle,
          contentDescription = null,
          tint = SproutGreenDark,
          modifier = Modifier.size(48.dp)
        )
      },
      title = {
        Text(
          text = "تم إرسال استمارة التسجيل بنجاح! 🎉",
          fontSize = 17.sp,
          fontWeight = FontWeight.Bold,
          color = SalsabeelBlueDark,
          textAlign = TextAlign.Center
        )
      },
      text = {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text(
            text = "تم استلام ملف الطفل (${registrationData.childFullName.ifBlank { "الطفل" }}) بالرقم المرجعي: ${registrationData.id} لدى إدارة روضة السلسبيل.",
            fontSize = 13.5.sp,
            color = DarkText,
            lineHeight = 22.sp,
            textAlign = TextAlign.Center
          )
          Spacer(modifier = Modifier.height(8.dp))
          Text(
            text = "يمكنك تحميل نسخة الاستمارة الرسمية بصيغة PDF الآن أو تسجيل طفل آخر في نفس العائلة مباشرة.",
            fontSize = 12.sp,
            color = MutedText,
            textAlign = TextAlign.Center
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            showSuccessDialog = false
            PdfRegistrationExporter.generateAndSharePdf(context, registrationData)
          },
          shape = RoundedCornerShape(10.dp),
          colors = ButtonDefaults.buttonColors(containerColor = SalsabeelBlue)
        ) {
          Icon(imageVector = Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(15.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("تحميل PDF 📄", fontSize = 11.5.sp)
        }
      },
      dismissButton = {
        TextButton(onClick = { showSuccessDialog = false }) {
          Text("إغلاق", color = MutedText)
        }
      }
    )
  }
}

// ----------------------------------------------------------------------
// HELPER: STATIC ACCORDION IMAGE CARD (P1, P2, P3, P6, P8)
// ----------------------------------------------------------------------
@Composable
private fun AccordionImageCard(
  imageRes: Int,
  contentDescription: String,
  backgroundColor: Color,
  borderColor: Color,
  imageHeight: androidx.compose.ui.unit.Dp
) {
  Card(
    shape = RoundedCornerShape(22.dp),
    colors = CardDefaults.cardColors(containerColor = backgroundColor),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    border = BorderStroke(1.5.dp, borderColor),
    modifier = Modifier.fillMaxWidth()
  ) {
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 14.dp, vertical = 12.dp),
      contentAlignment = Alignment.Center
    ) {
      Image(
        painter = painterResource(id = imageRes),
        contentDescription = contentDescription,
        contentScale = ContentScale.Fit,
        modifier = Modifier
          .fillMaxWidth()
          .height(imageHeight)
      )
    }
  }
}

// ----------------------------------------------------------------------
// HELPER: EXPANDABLE SECTION CARD (P4, P5, P7, P9, PP10)
// ----------------------------------------------------------------------
@Composable
private fun ExpandableSectionCard(
  imageRes: Int,
  contentDescription: String,
  backgroundColor: Color,
  borderColor: Color,
  ribbonHeight: androidx.compose.ui.unit.Dp,
  isExpanded: Boolean,
  onToggleExpand: () -> Unit,
  badgeText: String,
  content: @Composable () -> Unit
) {
  val arrowRotation by animateFloatAsState(
    targetValue = if (isExpanded) 180f else 0f,
    animationSpec = tween(durationMillis = 250),
    label = "arrow_rotation"
  )

  Card(
    shape = RoundedCornerShape(22.dp),
    colors = CardDefaults.cardColors(containerColor = backgroundColor),
    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
    border = BorderStroke(1.5.dp, borderColor),
    modifier = Modifier
      .fillMaxWidth()
      .animateContentSize()
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 14.dp, vertical = 12.dp)
    ) {
      // Header Ribbon Area (Clickable to toggle)
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(14.dp))
          .clickable { onToggleExpand() }
          .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Box(modifier = Modifier.weight(1f)) {
          Image(
            painter = painterResource(id = imageRes),
            contentDescription = contentDescription,
            contentScale = ContentScale.Fit,
            modifier = Modifier
              .fillMaxWidth()
              .height(ribbonHeight)
          )
        }

        Spacer(modifier = Modifier.width(6.dp))

        // Indicator Arrow Pill
        Surface(
          shape = CircleShape,
          color = PureWhite,
          shadowElevation = 1.dp,
          modifier = Modifier.size(34.dp)
        ) {
          Box(contentAlignment = Alignment.Center) {
            Icon(
              imageVector = Icons.Default.ExpandMore,
              contentDescription = if (isExpanded) "طي" else "توسيع",
              tint = DarkText,
              modifier = Modifier
                .size(20.dp)
                .rotate(arrowRotation)
            )
          }
        }
      }

      // Expandable Form Body
      AnimatedVisibility(visible = isExpanded) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(top = 10.dp)
        ) {
          content()
        }
      }
    }
  }
}

// ----------------------------------------------------------------------
// HELPER: OPT-IN FLOW ROW FOR BLOOD GROUPS
// ----------------------------------------------------------------------
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun OptInFlowRow(
  bloodGroups: List<String>,
  selectedGroup: String,
  onSelect: (String) -> Unit
) {
  FlowRow(
    horizontalArrangement = Arrangement.spacedBy(6.dp),
    verticalArrangement = Arrangement.spacedBy(6.dp)
  ) {
    bloodGroups.forEach { bg ->
      val isSelected = selectedGroup == bg
      FilterChip(
        selected = isSelected,
        onClick = { onSelect(bg) },
        label = { Text(bg, fontSize = 12.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
        colors = FilterChipDefaults.filterChipColors(
          selectedContainerColor = JoyPink,
          selectedLabelColor = PureWhite
        )
      )
    }
  }
}

// ----------------------------------------------------------------------
// HELPER: FORM FIELD WITH CUSTOM STYLING
// ----------------------------------------------------------------------
@Composable
private fun BrochureFormField(
  label: String,
  value: String,
  onValueChange: (String) -> Unit,
  placeholder: String,
  keyboardType: KeyboardType = KeyboardType.Text,
  minLines: Int = 1
) {
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 4.dp)
  ) {
    Text(
      text = label,
      fontSize = 12.5.sp,
      fontWeight = FontWeight.Bold,
      color = Color(0xFF334155),
      modifier = Modifier.padding(bottom = 3.dp)
    )
    OutlinedTextField(
      value = value,
      onValueChange = onValueChange,
      placeholder = { Text(placeholder, fontSize = 12.sp, color = Color(0xFF94A3B8)) },
      singleLine = minLines == 1,
      minLines = minLines,
      keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
      shape = RoundedCornerShape(12.dp),
      colors = OutlinedTextFieldDefaults.colors(
        unfocusedContainerColor = PureWhite,
        focusedContainerColor = PureWhite,
        unfocusedBorderColor = Color(0xFFCBD5E1),
        focusedBorderColor = SalsabeelBlue
      ),
      modifier = Modifier.fillMaxWidth()
    )
  }
}

// ----------------------------------------------------------------------
// HELPER: HEALTH QUESTION (YES / NO) WITH DETAILS PROMPT
// ----------------------------------------------------------------------
@Composable
private fun BrochureHealthQuestion(
  question: String,
  isYes: Boolean,
  details: String,
  detailsPrompt: String,
  onToggle: (Boolean) -> Unit,
  onDetailsChange: (String) -> Unit
) {
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 5.dp)
      .clip(RoundedCornerShape(12.dp))
      .background(PureWhite)
      .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(12.dp))
      .padding(10.dp)
  ) {
    Text(
      text = question,
      fontSize = 12.5.sp,
      fontWeight = FontWeight.Bold,
      color = Color(0xFF1E293B)
    )

    Spacer(modifier = Modifier.height(6.dp))

    Row(
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      // Yes pill
      Surface(
        shape = RoundedCornerShape(8.dp),
        color = if (isYes) Color(0xFFEF4444) else Color(0xFFF1F5F9),
        modifier = Modifier
          .clickable { onToggle(true) }
          .padding(vertical = 2.dp)
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          if (isYes) {
            Icon(Icons.Default.Check, contentDescription = null, tint = PureWhite, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
          }
          Text(
            text = "نعم",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = if (isYes) PureWhite else Color(0xFF475569)
          )
        }
      }

      // No pill
      Surface(
        shape = RoundedCornerShape(8.dp),
        color = if (!isYes) SproutGreenDark else Color(0xFFF1F5F9),
        modifier = Modifier
          .clickable { onToggle(false) }
          .padding(vertical = 2.dp)
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          if (!isYes) {
            Icon(Icons.Default.Check, contentDescription = null, tint = PureWhite, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
          }
          Text(
            text = "لا",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = if (!isYes) PureWhite else Color(0xFF475569)
          )
        }
      }
    }

    AnimatedVisibility(visible = isYes) {
      Column(modifier = Modifier.padding(top = 8.dp)) {
        Text(
          text = detailsPrompt,
          fontSize = 11.5.sp,
          color = Color(0xFFB91C1C),
          fontWeight = FontWeight.SemiBold
        )
        Spacer(modifier = Modifier.height(4.dp))
        OutlinedTextField(
          value = details,
          onValueChange = onDetailsChange,
          placeholder = { Text("يرجى كتابة التوضيح هنا...", fontSize = 12.sp) },
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier.fillMaxWidth()
        )
      }
    }
  }
}
