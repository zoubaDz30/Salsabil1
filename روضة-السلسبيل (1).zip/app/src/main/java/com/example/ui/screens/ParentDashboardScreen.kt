package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.AppRegistration
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Celebration
import androidx.compose.material.icons.filled.ChildCare
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.example.R
import com.example.data.model.REGISTRATION_STATUS_ACCEPTED
import com.example.data.model.REGISTRATION_STATUS_ERROR
import com.example.data.model.REGISTRATION_STATUS_PENDING
import com.example.data.model.ChildRegistration
import com.example.ui.theme.DarkText
import com.example.ui.theme.JoyPink
import com.example.ui.theme.JoyPinkDark
import com.example.ui.theme.MutedText
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SalsabeelBlue
import com.example.ui.theme.SalsabeelBlueDark
import com.example.ui.theme.SalsabeelBlueLight
import com.example.ui.theme.SproutGreenDark
import com.example.ui.viewmodel.DashboardViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

enum class ParentSection(val title: String, val icon: ImageVector) {
  HOME("لوحة التحكم", Icons.Default.ChildCare),
  REGISTER_CHILD("تسجيل الابن في روضة", Icons.Default.AppRegistration),
  CHILDREN("قسم الابناء", Icons.Default.ChildCare),
  SCHEDULE("جدول الروضة", Icons.Default.CalendarMonth),
  ACTIVITIES("قسم الانشطة و الفعاليات", Icons.Default.Celebration),
  FEES("الرسوم الشهرية", Icons.Default.CreditCard),
  CONTACT_ADMIN("قسم التواصل مع الادارة", Icons.AutoMirrored.Filled.Chat)
}

// Eye-safe, muted pastel tones for the drawer that cycle on each open/close
private val MutedPastelColors = listOf(
  Color(0xFFF0FDF4), // Soft Pastel Mint
  Color(0xFFF0F9FF), // Soft Baby Azure
  Color(0xFFFDF2F8), // Soft Warm Rose
  Color(0xFFFAF5FF), // Soft Pastel Lavender
  Color(0xFFFEFCE8)  // Soft Warm Cream
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ParentDashboardScreen(
  parentName: String = "ولي الأمر",
  onLogout: () -> Unit = {},
  onOpenSettings: () -> Unit = {},
  dashboardViewModel: DashboardViewModel = viewModel()
) {
  val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
  val scope = rememberCoroutineScope()

  var currentSection by remember { mutableStateOf(ParentSection.HOME) }
  var editingRegistration by remember { mutableStateOf<ChildRegistration?>(null) }
  var colorIndex by remember { mutableIntStateOf(0) }
  var wasDrawerOpen by remember { mutableStateOf(false) }

  // Gentle non-intrusive welcome toast/banner
  var showWelcomeBanner by remember { mutableStateOf(true) }

  // Auto-dismiss the welcome banner smoothly after 3.5 seconds
  LaunchedEffect(Unit) {
    delay(3500)
    showWelcomeBanner = false
  }

  // Detect whenever drawer opens or closes to smoothly cycle the pastel color
  LaunchedEffect(drawerState.isOpen) {
    if (drawerState.isOpen != wasDrawerOpen) {
      wasDrawerOpen = drawerState.isOpen
      if (drawerState.isOpen) {
        colorIndex = (colorIndex + 1) % MutedPastelColors.size
      }
    }
  }

  val activeDrawerPastelColor = MutedPastelColors[colorIndex]

  ModalNavigationDrawer(
    drawerState = drawerState,
    drawerContent = {
      ModalDrawerSheet(
        modifier = Modifier
          .fillMaxHeight()
          .width(300.dp)
          .testTag("parent_drawer"),
        drawerShape = RoundedCornerShape(topEnd = 28.dp, bottomEnd = 28.dp),
        drawerContainerColor = activeDrawerPastelColor
      ) {
        Column(
          modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 20.dp)
        ) {
          // Drawer Header: Kindergarten logo with greeting
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Image(
                painter = painterResource(id = R.drawable.logo),
                contentDescription = "شعار الروضة",
                contentScale = ContentScale.Fit,
                modifier = Modifier
                  .size(46.dp)
                  .clip(CircleShape)
              )
              Spacer(modifier = Modifier.width(12.dp))
              Column {
                Text(
                  text = "روضة السلسبيل",
                  fontSize = 16.sp,
                  fontWeight = FontWeight.Bold,
                  color = SalsabeelBlueDark
                )
                Text(
                  text = "بوابة ولي الأمر 👨‍👩‍👧",
                  fontSize = 12.sp,
                  color = MutedText
                )
              }
            }

            IconButton(
              onClick = { scope.launch { drawerState.close() } }
            ) {
              Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "إغلاق القائمة",
                tint = MutedText
              )
            }
          }

          Spacer(modifier = Modifier.height(20.dp))

          // Drawer Navigation Items (The exact 6 requested sections)
          Column(
            modifier = Modifier
              .weight(1f)
              .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            DrawerSectionItem(
              title = ParentSection.REGISTER_CHILD.title,
              icon = ParentSection.REGISTER_CHILD.icon,
              isSelected = currentSection == ParentSection.REGISTER_CHILD,
              onClick = {
                currentSection = ParentSection.REGISTER_CHILD
                scope.launch { drawerState.close() }
              }
            )

            DrawerSectionItem(
              title = ParentSection.CHILDREN.title,
              icon = ParentSection.CHILDREN.icon,
              isSelected = currentSection == ParentSection.CHILDREN,
              onClick = {
                currentSection = ParentSection.CHILDREN
                scope.launch { drawerState.close() }
              }
            )

            DrawerSectionItem(
              title = ParentSection.SCHEDULE.title,
              icon = ParentSection.SCHEDULE.icon,
              isSelected = currentSection == ParentSection.SCHEDULE,
              onClick = {
                currentSection = ParentSection.SCHEDULE
                scope.launch { drawerState.close() }
              }
            )

            DrawerSectionItem(
              title = ParentSection.ACTIVITIES.title,
              icon = ParentSection.ACTIVITIES.icon,
              isSelected = currentSection == ParentSection.ACTIVITIES,
              onClick = {
                currentSection = ParentSection.ACTIVITIES
                scope.launch { drawerState.close() }
              }
            )

            DrawerSectionItem(
              title = ParentSection.FEES.title,
              icon = ParentSection.FEES.icon,
              isSelected = currentSection == ParentSection.FEES,
              onClick = {
                currentSection = ParentSection.FEES
                scope.launch { drawerState.close() }
              }
            )

            DrawerSectionItem(
              title = ParentSection.CONTACT_ADMIN.title,
              icon = ParentSection.CONTACT_ADMIN.icon,
              isSelected = currentSection == ParentSection.CONTACT_ADMIN,
              onClick = {
                currentSection = ParentSection.CONTACT_ADMIN
                scope.launch { drawerState.close() }
              }
            )
          }

          // Bottom Logout Option
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(14.dp))
              .clickable { onLogout() }
              .padding(vertical = 12.dp, horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.ExitToApp,
              contentDescription = "تسجيل الخروج",
              tint = JoyPinkDark,
              modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
              text = "تسجيل الخروج",
              fontSize = 14.sp,
              fontWeight = FontWeight.Medium,
              color = JoyPinkDark
            )
          }
        }
      }
    }
  ) {
    Scaffold(
      topBar = {
        TopAppBar(
          title = {
            // Logo in the middle/start of top bar
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.Center,
              modifier = Modifier.fillMaxWidth()
            ) {
              Image(
                painter = painterResource(id = R.drawable.logo),
                contentDescription = "شعار روضة السلسبيل",
                contentScale = ContentScale.Fit,
                modifier = Modifier
                  .size(38.dp)
                  .testTag("top_kindergarten_logo")
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "روضة السلسبيل",
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                color = SalsabeelBlueDark
              )
            }
          },
          navigationIcon = {
            // Sidebar menu button to open drawer
            IconButton(
              onClick = { scope.launch { drawerState.open() } },
              modifier = Modifier.testTag("parent_menu_button")
            ) {
              Icon(
                imageVector = Icons.Default.Menu,
                contentDescription = "فتح القائمة الجانبية",
                tint = SalsabeelBlueDark
              )
            }
          },
          actions = {
            // Settings button across from the kindergarten logo
            IconButton(
              onClick = onOpenSettings,
              modifier = Modifier.testTag("parent_settings_button")
            ) {
              Icon(
                imageVector = Icons.Default.Settings,
                contentDescription = "الإعدادات",
                tint = SalsabeelBlueDark
              )
            }
          },
          colors = TopAppBarDefaults.topAppBarColors(
            containerColor = PureWhite,
            titleContentColor = SalsabeelBlueDark
          ),
          modifier = Modifier.shadow(2.dp)
        )
      },
      containerColor = Color(0xFFF9FBFC)
    ) { innerPadding ->
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(innerPadding)
          .testTag("parent_dashboard_content")
      ) {
        // Main view content based on selected section
        when (currentSection) {
          ParentSection.REGISTER_CHILD -> {
            ChildRegistrationScreen(
              onNavigateBack = { 
                currentSection = ParentSection.HOME
                editingRegistration = null
              },
              initialRegistration = editingRegistration,
              viewModel = dashboardViewModel
            )
          }
          ParentSection.CHILDREN -> {
            ChildrenSectionView(
              viewModel = dashboardViewModel,
              onEditRegistration = { registration ->
                editingRegistration = registration
                currentSection = ParentSection.REGISTER_CHILD
              }
            )
          }
          ParentSection.HOME -> {
            HomeParentDashboardView(
              onOpenRegisterChild = { currentSection = ParentSection.REGISTER_CHILD }
            )
          }
          else -> {
            EmptySectionPlaceholder(section = currentSection)
          }
        }
      }
    }
  }
}

@Composable
private fun DrawerSectionItem(
  title: String,
  icon: ImageVector,
  isSelected: Boolean,
  onClick: () -> Unit
) {
  val backgroundColor = if (isSelected) PureWhite else Color.Transparent
  val textColor = if (isSelected) SalsabeelBlueDark else DarkText
  val iconTint = if (isSelected) SalsabeelBlue else MutedText

  Surface(
    shape = RoundedCornerShape(14.dp),
    color = backgroundColor,
    shadowElevation = if (isSelected) 2.dp else 0.dp,
    modifier = Modifier
      .fillMaxWidth()
      .clickable { onClick() }
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 14.dp, vertical = 12.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Icon(
        imageVector = icon,
        contentDescription = null,
        tint = iconTint,
        modifier = Modifier.size(22.dp)
      )
      Spacer(modifier = Modifier.width(12.dp))
      Text(
        text = title,
        fontSize = 14.sp,
        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
        color = textColor
      )
    }
  }
}

@Composable
private fun ChildrenSectionView(
  viewModel: DashboardViewModel,
  onEditRegistration: (ChildRegistration) -> Unit
) {
  val registrations by viewModel.registrations.collectAsStateWithLifecycle()
  var selectedRegistrationForFile by remember { mutableStateOf<ChildRegistration?>(null) }

  if (registrations.isEmpty()) {
    EmptySectionPlaceholder(section = ParentSection.CHILDREN)
  } else {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(16.dp)
    ) {
      Text(
        text = "قائمة الأبناء المسجلين 👶",
        fontSize = 18.sp,
        fontWeight = FontWeight.Bold,
        color = SalsabeelBlueDark,
        modifier = Modifier.padding(bottom = 16.dp)
      )

      LazyColumn(
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxSize()
      ) {
        items(registrations) { registration ->
          ChildRegistrationCard(
            registration = registration,
            onShowFileRequirements = { selectedRegistrationForFile = registration },
            onEdit = { onEditRegistration(registration) }
          )
        }
      }
    }
  }

  if (selectedRegistrationForFile != null) {
    ApplicationFileRequirementsDialog(
      registration = selectedRegistrationForFile!!,
      onDismiss = { selectedRegistrationForFile = null }
    )
  }
}

@Composable
private fun ChildRegistrationCard(
  registration: ChildRegistration,
  onShowFileRequirements: () -> Unit,
  onEdit: () -> Unit
) {
  val statusColor = when (registration.status) {
    REGISTRATION_STATUS_ACCEPTED -> Color(0xFF10B981)
    REGISTRATION_STATUS_ERROR -> Color(0xFFEF4444)
    else -> Color(0xFFF59E0B)
  }

  val statusIcon = when (registration.status) {
    REGISTRATION_STATUS_ACCEPTED -> Icons.Default.TaskAlt
    REGISTRATION_STATUS_ERROR -> Icons.Default.Error
    else -> Icons.Default.HourglassEmpty
  }

  Card(
    modifier = Modifier
      .fillMaxWidth()
      .shadow(4.dp, RoundedCornerShape(16.dp)),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = PureWhite)
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        // Child Photo
        Box(
          modifier = Modifier
            .size(70.dp)
            .clip(CircleShape)
            .background(Color(0xFFF1F5F9))
            .border(2.dp, statusColor, CircleShape),
          contentAlignment = Alignment.Center
        ) {
          if (registration.childPhotoUri != null) {
            AsyncImage(
              model = registration.childPhotoUri,
              contentDescription = null,
              contentScale = ContentScale.Crop,
              modifier = Modifier.fillMaxSize()
            )
          } else {
            Icon(
              imageVector = Icons.Default.ChildCare,
              contentDescription = null,
              tint = SalsabeelBlue,
              modifier = Modifier.size(36.dp)
            )
          }
        }

        Spacer(modifier = Modifier.width(16.dp))

        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = registration.childFullName.ifBlank { "لم يتم تحديد الاسم" },
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = DarkText
          )
          Text(
            text = registration.educationalLevel,
            fontSize = 13.sp,
            color = MutedText
          )
          Spacer(modifier = Modifier.height(4.dp))
          Surface(
            color = statusColor.copy(alpha = 0.1f),
            shape = RoundedCornerShape(8.dp)
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
              Icon(
                imageVector = statusIcon,
                contentDescription = null,
                tint = statusColor,
                modifier = Modifier.size(14.dp)
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = registration.status,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = statusColor
              )
            }
          }
        }
      }

      if (registration.status == REGISTRATION_STATUS_ERROR && registration.adminFeedback.isNotBlank()) {
        Spacer(modifier = Modifier.height(12.dp))
        Surface(
          color = Color(0xFFFEF2F2),
          shape = RoundedCornerShape(8.dp),
          border = BorderStroke(1.dp, Color(0xFFFCA5A5)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(10.dp)) {
            Text(
              text = "ملاحظة الإدارة ⚠️",
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              color = Color(0xFF991B1B)
            )
            Text(
              text = registration.adminFeedback,
              fontSize = 12.sp,
              color = Color(0xFF991B1B)
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        if (registration.status == REGISTRATION_STATUS_ACCEPTED) {
          Button(
            onClick = onShowFileRequirements,
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = SalsabeelBlue)
          ) {
            Icon(Icons.Default.Description, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("ملف تقديم للادارة", fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }
        }

        if (registration.status == REGISTRATION_STATUS_ERROR) {
          Button(
            onClick = onEdit,
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF64748B))
          ) {
            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("تعديل الطلب", fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}

@Composable
private fun ApplicationFileRequirementsDialog(
  registration: ChildRegistration,
  onDismiss: () -> Unit
) {
  AlertDialog(
    onDismissRequest = onDismiss,
    icon = {
      Icon(
        imageVector = Icons.Default.Description,
        contentDescription = null,
        tint = SalsabeelBlue,
        modifier = Modifier.size(48.dp)
      )
    },
    title = {
      Text(
        text = "ملف التقديم للإدارة 📑",
        fontSize = 18.sp,
        fontWeight = FontWeight.Bold,
        color = SalsabeelBlueDark,
        textAlign = TextAlign.Center
      )
    },
    text = {
      Column(modifier = Modifier.fillMaxWidth()) {
        Text(
          text = "تهانينا! تم قبول طلب تسجيل (${registration.childFullName}). يرجى تحضير الملف التالي وتقديمه للإدارة:",
          fontSize = 14.sp,
          color = DarkText,
          textAlign = TextAlign.Right,
          lineHeight = 22.sp
        )
        Spacer(modifier = Modifier.height(16.dp))
        
        val requirements = listOf(
          "1. نسخة من الدفتر العائلي (صفحة الطفل).",
          "2. شهادة ميلاد الطفل (رقم 12).",
          "3. شهادة طبية (عامة و صدرية) تثبت سلامة الطفل.",
          "4. نسخة من دفتر التلقيحات.",
          "5. 4 صور شمسية للطفل.",
          "6. استمارة التسجيل الإلكترونية (محملة بصيغة PDF)."
        )

        requirements.forEach { req ->
          Text(
            text = req,
            fontSize = 13.sp,
            color = MutedText,
            modifier = Modifier.padding(vertical = 4.dp),
            textAlign = TextAlign.Right
          )
        }
      }
    },
    confirmButton = {
      Button(
        onClick = onDismiss,
        colors = ButtonDefaults.buttonColors(containerColor = SalsabeelBlue),
        shape = RoundedCornerShape(12.dp)
      ) {
        Text("حسناً")
      }
    }
  )
}

@Composable
private fun EmptySectionPlaceholder(section: ParentSection) {
  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(32.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.Center
  ) {
    Box(
      modifier = Modifier
        .size(80.dp)
        .clip(CircleShape)
        .background(Color(0xFFF1F5F9)),
      contentAlignment = Alignment.Center
    ) {
      Icon(
        imageVector = section.icon,
        contentDescription = null,
        tint = SalsabeelBlue,
        modifier = Modifier.size(40.dp)
      )
    }

    Spacer(modifier = Modifier.height(18.dp))

    Text(
      text = section.title,
      fontSize = 20.sp,
      fontWeight = FontWeight.Bold,
      color = SalsabeelBlueDark,
      textAlign = TextAlign.Center
    )

    Spacer(modifier = Modifier.height(8.dp))

    Text(
      text = "هذا القسم جاهز وفارغ حالياً، وسيتم تنظيمه وتنسيقه في الخطوة القادمة.",
      fontSize = 14.sp,
      color = MutedText,
      textAlign = TextAlign.Center,
      lineHeight = 22.sp
    )
  }
}

@Composable
private fun HomeParentDashboardView(
  onOpenRegisterChild: () -> Unit
) {
  Box(
    modifier = Modifier
      .fillMaxSize()
      .padding(24.dp),
    contentAlignment = Alignment.Center
  ) {
    Column(
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center
    ) {
      Image(
        painter = painterResource(id = R.drawable.logo),
        contentDescription = "روضة السلسبيل",
        contentScale = ContentScale.Fit,
        modifier = Modifier
          .size(110.dp)
          .clip(CircleShape)
      )

      Spacer(modifier = Modifier.height(16.dp))

      Text(
        text = "روضة السلسبيل 🌸",
        fontSize = 20.sp,
        fontWeight = FontWeight.Bold,
        color = SalsabeelBlueDark
      )

      Spacer(modifier = Modifier.height(6.dp))

      Text(
        text = "نغرس القيم .. ننمي المستقبل",
        fontSize = 13.sp,
        color = MutedText,
        textAlign = TextAlign.Center
      )

      Spacer(modifier = Modifier.height(28.dp))

      Button(
        onClick = onOpenRegisterChild,
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(containerColor = SalsabeelBlue),
        modifier = Modifier
          .fillMaxWidth()
          .height(52.dp)
          .testTag("open_child_registration_btn")
      ) {
        Icon(
          imageVector = Icons.Default.AppRegistration,
          contentDescription = null,
          modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(10.dp))
        Text(
          text = "استمارة معلومات الطفل (تسجيل جديد) 📝",
          fontSize = 14.sp,
          fontWeight = FontWeight.Bold
        )
      }

      Spacer(modifier = Modifier.height(14.dp))

      Text(
        text = "يمكنك فتح القائمة الجانبية ☰ لتصفح باقي الأقسام",
        fontSize = 12.sp,
        color = Color(0xFF94A3B8),
        textAlign = TextAlign.Center
      )
    }
  }
}


