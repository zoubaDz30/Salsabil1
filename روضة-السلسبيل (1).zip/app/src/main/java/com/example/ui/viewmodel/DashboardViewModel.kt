package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.ChildRegistration
import com.example.data.repository.RegistrationRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class DashboardViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: RegistrationRepository
    val registrations: StateFlow<List<ChildRegistration>>

    init {
        val registrationDao = AppDatabase.getDatabase(application).registrationDao()
        repository = RegistrationRepository(registrationDao)
        registrations = repository.allRegistrations.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
    }

    fun submitRegistration(registration: ChildRegistration) {
        viewModelScope.launch {
            repository.insert(registration.copy(isSubmittedToAdmin = true))
        }
    }

    fun updateRegistration(registration: ChildRegistration) {
        viewModelScope.launch {
            repository.update(registration)
        }
    }
}
