package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Celebration
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Spa
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.DarkText
import com.example.ui.theme.JoyPink
import com.example.ui.theme.JoyPinkDark
import com.example.ui.theme.JoyPinkLight
import com.example.ui.theme.MutedText
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SalsabeelBlue
import com.example.ui.theme.SalsabeelBlueDark
import com.example.ui.theme.SalsabeelBlueLight
import com.example.ui.theme.SproutGreen
import com.example.ui.theme.SproutGreenDark
import com.example.ui.theme.SproutGreenLight
import com.example.ui.theme.SunshineLight
import com.example.ui.theme.SunshineYellow

@Composable
fun WelcomeScreen(
  modifier: Modifier = Modifier,
  onEnterClicked: () -> Unit = {}
) {
  var showWelcomeNotice by remember { mutableStateOf(false) }

  // Subtle breathing animation for the logo
  val infiniteTransition = rememberInfiniteTransition(label = "logo_breathe")
  val logoScale by infiniteTransition.animateFloat(
    initialValue = 0.98f,
    targetValue = 1.03f,
    animationSpec = infiniteRepeatable(
      animation = tween(1800, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "breathe"
  )

  Surface(
    modifier = modifier
      .fillMaxSize()
      .testTag("welcome_screen"),
    color = Color(0xFFF8FAFC)
  ) {
    Box(
      modifier = Modifier
        .fillMaxSize()
        .background(
          brush = Brush.verticalGradient(
            colors = listOf(
              Color(0xFFF0F9FF), // Soft azure (from logo)
              Color(0xFFFDF4FF), // Soft joyful pink tint
              Color(0xFFF0FDF4)  // Soft fresh green (from logo)
            )
          )
        )
    ) {
      // Decorative background accents matching logo colors
      Box(
        modifier = Modifier
          .align(Alignment.TopStart)
          .padding(top = 40.dp, start = 20.dp)
          .size(80.dp)
          .clip(CircleShape)
          .background(SalsabeelBlue.copy(alpha = 0.12f))
      )
      Box(
        modifier = Modifier
          .align(Alignment.TopEnd)
          .padding(top = 70.dp, end = 25.dp)
          .size(55.dp)
          .clip(CircleShape)
          .background(JoyPink.copy(alpha = 0.14f))
      )
      Box(
        modifier = Modifier
          .align(Alignment.BottomStart)
          .padding(bottom = 90.dp, start = 30.dp)
          .size(90.dp)
          .clip(CircleShape)
          .background(SproutGreen.copy(alpha = 0.12f))
      )

      Column(
        modifier = Modifier
          .fillMaxSize()
          .verticalScroll(rememberScrollState())
          .padding(horizontal = 24.dp, vertical = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
      ) {
        Spacer(modifier = Modifier.height(16.dp))

        // Kindergarten Logo in a rounded card with a double harmonic border
        Card(
          shape = RoundedCornerShape(32.dp),
          colors = CardDefaults.cardColors(containerColor = PureWhite),
          elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
          modifier = Modifier
            .scale(logoScale)
            .size(210.dp)
            .border(
              width = 3.dp,
              brush = Brush.linearGradient(
                listOf(SalsabeelBlue, SproutGreen, JoyPink)
              ),
              shape = RoundedCornerShape(32.dp)
            )
            .testTag("welcome_logo")
        ) {
          Box(
            modifier = Modifier
              .fillMaxSize()
              .padding(14.dp),
            contentAlignment = Alignment.Center
          ) {
            Image(
              painter = painterResource(id = R.drawable.logo),
              contentDescription = "شعار روضة السلسبيل",
              contentScale = ContentScale.Fit,
              modifier = Modifier.fillMaxSize()
            )
          }
        }

        Spacer(modifier = Modifier.height(26.dp))

        // Kindergarten Name in Salsabeel Blue
        Text(
          text = "روضة السلسبيل",
          fontSize = 30.sp,
          fontWeight = FontWeight.ExtraBold,
          color = SalsabeelBlueDark,
          textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(6.dp))

        // Core Values Badge row in logo colors
        Row(
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.padding(vertical = 6.dp)
        ) {
          ValuePill(text = "إبداع", bg = JoyPinkLight, fg = JoyPinkDark, icon = Icons.Default.Star)
          ValuePill(text = "نمو", bg = SproutGreenLight, fg = SproutGreenDark, icon = Icons.Default.Spa)
          ValuePill(text = "رعاية", bg = SalsabeelBlueLight, fg = SalsabeelBlueDark, icon = Icons.Default.WaterDrop)
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Warm, inspiring welcome message
        Card(
          shape = RoundedCornerShape(20.dp),
          colors = CardDefaults.cardColors(containerColor = PureWhite.copy(alpha = 0.92f)),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(
            modifier = Modifier.padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Text(
              text = "أهلاً بكم في روضة السلسبيل 🌟",
              fontSize = 17.sp,
              fontWeight = FontWeight.Bold,
              color = DarkText,
              textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
              text = "حيث تنمو مواهب أطفالنا وتزهر أحلامهم في بيئة آمنة ومبهجة تجمع بين متعة اللعب وجودة التعليم.",
              fontSize = 14.sp,
              color = MutedText,
              textAlign = TextAlign.Center,
              lineHeight = 22.sp
            )
          }
        }

        Spacer(modifier = Modifier.height(28.dp))

        // Primary Action Button (Option 2)
        Button(
          onClick = onEnterClicked,
          shape = RoundedCornerShape(16.dp),
          colors = ButtonDefaults.buttonColors(
            containerColor = SalsabeelBlue,
            contentColor = PureWhite
          ),
          elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp),
          modifier = Modifier
            .fillMaxWidth()
            .height(54.dp)
            .testTag("enter_kindergarten_btn")
        ) {
          Icon(
            imageVector = Icons.Default.AutoAwesome,
            contentDescription = null,
            tint = SunshineYellow,
            modifier = Modifier.size(20.dp)
          )
          Spacer(modifier = Modifier.width(10.dp))
          Text(
            text = "دخول الروضة ✨",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold
          )
        }

        Spacer(modifier = Modifier.height(16.dp))
      }
    }

    // Welcome interactive feedback dialog
    if (showWelcomeNotice) {
      AlertDialog(
        onDismissRequest = { showWelcomeNotice = false },
        title = {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.Celebration,
              contentDescription = null,
              tint = JoyPink,
              modifier = Modifier.size(26.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "مرحباً بكم في روضة السلسبيل",
              fontSize = 16.sp,
              fontWeight = FontWeight.Bold,
              color = SalsabeelBlueDark
            )
          }
        },
        text = {
          Text(
            text = "تم تثبيت شاشة الترحيب بنجاح بألوان متناسقة تماماً مع شعار الروضة. نحن جاهزون للانتقال معك إلى الخطوة القادمة!",
            fontSize = 14.sp,
            color = DarkText,
            lineHeight = 20.sp
          )
        },
        confirmButton = {
          Button(
            onClick = { showWelcomeNotice = false },
            colors = ButtonDefaults.buttonColors(containerColor = SalsabeelBlue)
          ) {
            Text("رائع")
          }
        }
      )
    }
  }
}

@Composable
fun ValuePill(
  text: String,
  bg: Color,
  fg: Color,
  icon: androidx.compose.ui.graphics.vector.ImageVector
) {
  Surface(
    shape = RoundedCornerShape(50),
    color = bg
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
      Icon(
        imageVector = icon,
        contentDescription = null,
        tint = fg,
        modifier = Modifier.size(13.dp)
      )
      Spacer(modifier = Modifier.width(4.dp))
      Text(
        text = text,
        color = fg,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold
      )
    }
  }
}
