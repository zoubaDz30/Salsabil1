package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Colors extracted and harmonized directly from the Kindergarten Logo
val SalsabeelBlue = Color(0xFF0070D0)       // Main logo azure / water stream blue
val SalsabeelBlueDark = Color(0xFF0055A0)   // Deep logo blue for typography
val SalsabeelBlueLight = Color(0xFFE0F2FE)  // Soft sky tint

val SproutGreen = Color(0xFF6BB810)         // Kindergarten lively leaf green
val SproutGreenDark = Color(0xFF4D8B08)     // Darker green for text
val SproutGreenLight = Color(0xFFECFDF5)    // Mint tint

val JoyPink = Color(0xFFF05D9A)             // Joyful playful pink from logo
val JoyPinkDark = Color(0xFFBE185D)         // Rose text
val JoyPinkLight = Color(0xFFFDF2F8)        // Soft rose tint

val SunshineYellow = Color(0xFFF59E0B)      // Golden warm sun
val SunshineLight = Color(0xFFFEF3C7)

val DarkText = Color(0xFF0F172A)
val MutedText = Color(0xFF475569)
val PureWhite = Color(0xFFFFFFFF)
val WarmCanvas = Color(0xFFF8FAFC)
