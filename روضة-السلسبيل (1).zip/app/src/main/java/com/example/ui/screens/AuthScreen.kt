package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.FamilyRestroom
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MarkEmailRead
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.DarkText
import com.example.ui.theme.JoyPink
import com.example.ui.theme.JoyPinkDark
import com.example.ui.theme.JoyPinkLight
import com.example.ui.theme.MutedText
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SalsabeelBlue
import com.example.ui.theme.SalsabeelBlueDark
import com.example.ui.theme.SalsabeelBlueLight
import com.example.ui.theme.SproutGreen
import com.example.ui.theme.SproutGreenDark
import com.example.ui.theme.SproutGreenLight
import com.example.ui.theme.SunshineYellow

enum class UserRole {
  PARENT,
  ADMIN
}

enum class ParentAuthTab {
  LOGIN,
  REGISTER
}

@Composable
fun AuthScreen(
  onBackToWelcome: () -> Unit = {},
  onParentLoginSuccess: (String) -> Unit = {},
  onAdminLoginSuccess: (String) -> Unit = {}
) {
  var selectedRole by remember { mutableStateOf<UserRole?>(UserRole.PARENT) }
  var parentTab by remember { mutableStateOf(ParentAuthTab.LOGIN) }

  // Parent Login fields
  var parentLoginIdentifier by remember { mutableStateOf("") }
  var parentLoginPassword by remember { mutableStateOf("") }
  var parentLoginPasswordVisible by remember { mutableStateOf(false) }
  var parentRememberMe by remember { mutableStateOf(true) }

  // Parent Register fields
  var regEmail by remember { mutableStateOf("") }
  var regPhone by remember { mutableStateOf("") }
  var regPassword by remember { mutableStateOf("") }
  var regConfirmPassword by remember { mutableStateOf("") }
  var regPasswordVisible by remember { mutableStateOf(false) }

  // Admin Login fields
  var adminUsername by remember { mutableStateOf("") }
  var adminPassword by remember { mutableStateOf("") }
  var adminPasswordVisible by remember { mutableStateOf(false) }
  var adminRememberMe by remember { mutableStateOf(false) }

  // Forgot password dialog & simulation state
  var showForgotPasswordDialog by remember { mutableStateOf(false) }
  var forgotEmail by remember { mutableStateOf("") }
  var simulatedOtpCode by remember { mutableStateOf("") }
  var enteredOtp by remember { mutableStateOf("") }
  var newPassword by remember { mutableStateOf("") }
  var confirmNewPassword by remember { mutableStateOf("") }
  var isOtpSent by remember { mutableStateOf(false) }
  var forgotStatusMessage by remember { mutableStateOf("") }

  // Infinite animations for the orbiting glowing aurora around the logo
  val infiniteTransition = rememberInfiniteTransition(label = "aurora")
  val auroraRotation by infiniteTransition.animateFloat(
    initialValue = 0f,
    targetValue = 360f,
    animationSpec = infiniteRepeatable(
      animation = tween(9000, easing = LinearEasing),
      repeatMode = RepeatMode.Restart
    ),
    label = "rotation"
  )
  val glowPulse by infiniteTransition.animateFloat(
    initialValue = 0.85f,
    targetValue = 1.15f,
    animationSpec = infiniteRepeatable(
      animation = tween(2400, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "pulse"
  )

  Surface(
    modifier = Modifier
      .fillMaxSize()
      .testTag("auth_screen"),
    color = Color(0xFFF9FBFC)
  ) {
    Box(
      modifier = Modifier
        .fillMaxSize()
        .background(
          brush = Brush.verticalGradient(
            colors = listOf(
              Color(0xFFF0F9FF), // Light Azure
              Color(0xFFFDF4F9), // Subtle Rose
              Color(0xFFF2FBF5)  // Light Spring Green
            )
          )
        )
    ) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .verticalScroll(rememberScrollState())
          .padding(horizontal = 20.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        // Top navigation bar with Back button
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          IconButton(
            onClick = onBackToWelcome,
            modifier = Modifier
              .size(42.dp)
              .clip(CircleShape)
              .background(PureWhite.copy(alpha = 0.9f))
              .testTag("auth_back_btn")
          ) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.ArrowBack,
              contentDescription = "العودة للترحيب",
              tint = SalsabeelBlueDark
            )
          }

          Text(
            text = "تسجيل الدخول",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = SalsabeelBlueDark
          )

          Spacer(modifier = Modifier.size(42.dp))
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Kindergarten Logo WITHOUT FRAME with an orbiting colorful glowing aurora
        Box(
          contentAlignment = Alignment.Center,
          modifier = Modifier
            .size(190.dp)
            .testTag("logo_with_glow")
        ) {
          // Orbiting multi-colored ambient glow halo
          Box(
            modifier = Modifier
              .size(165.dp)
              .scale(glowPulse)
              .rotate(auroraRotation)
              .clip(CircleShape)
              .background(
                brush = Brush.sweepGradient(
                  colors = listOf(
                    SalsabeelBlue.copy(alpha = 0.40f),
                    SproutGreen.copy(alpha = 0.45f),
                    JoyPink.copy(alpha = 0.40f),
                    SunshineYellow.copy(alpha = 0.35f),
                    SalsabeelBlue.copy(alpha = 0.40f)
                  )
                )
              )
          )

          // Soft inner diffusion circle for eye comfort
          Box(
            modifier = Modifier
              .size(140.dp)
              .clip(CircleShape)
              .background(PureWhite.copy(alpha = 0.85f))
          )

          // The pure logo floating freely with no rectangular bounding box or border
          Image(
            painter = painterResource(id = R.drawable.logo),
            contentDescription = "شعار روضة السلسبيل",
            contentScale = ContentScale.Fit,
            modifier = Modifier
              .size(145.dp)
              .padding(8.dp)
          )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
          text = "روضة السلسبيل النموذجية",
          fontSize = 20.sp,
          fontWeight = FontWeight.ExtraBold,
          color = SalsabeelBlueDark
        )

        Text(
          text = "اختر نوع الحساب للمتابعة",
          fontSize = 13.sp,
          color = MutedText,
          modifier = Modifier.padding(top = 2.dp)
        )

        Spacer(modifier = Modifier.height(20.dp))

        // CARD 1: PARENTS CARD (Interactive Expanding Card)
        Card(
          shape = RoundedCornerShape(24.dp),
          colors = CardDefaults.cardColors(
            containerColor = if (selectedRole == UserRole.PARENT) PureWhite else PureWhite.copy(alpha = 0.75f)
          ),
          elevation = CardDefaults.cardElevation(
            defaultElevation = if (selectedRole == UserRole.PARENT) 6.dp else 2.dp
          ),
          modifier = Modifier
            .fillMaxWidth()
            .border(
              width = if (selectedRole == UserRole.PARENT) 2.dp else 1.dp,
              color = if (selectedRole == UserRole.PARENT) SalsabeelBlue else Color(0xFFE2E8F0),
              shape = RoundedCornerShape(24.dp)
            )
            .animateContentSize()
            .testTag("parent_role_card")
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(18.dp)
          ) {
            // Header click area to expand/collapse
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .clickable { selectedRole = UserRole.PARENT },
              verticalAlignment = Alignment.CenterVertically
            ) {
              Box(
                modifier = Modifier
                  .size(48.dp)
                  .clip(RoundedCornerShape(14.dp))
                  .background(
                    if (selectedRole == UserRole.PARENT) SalsabeelBlueLight else Color(0xFFF1F5F9)
                  ),
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  imageVector = Icons.Default.FamilyRestroom,
                  contentDescription = null,
                  tint = if (selectedRole == UserRole.PARENT) SalsabeelBlue else MutedText,
                  modifier = Modifier.size(28.dp)
                )
              }

              Spacer(modifier = Modifier.width(14.dp))

              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = "حساب أولياء الأمور 👨‍👩‍👧",
                  fontSize = 17.sp,
                  fontWeight = FontWeight.Bold,
                  color = if (selectedRole == UserRole.PARENT) SalsabeelBlueDark else DarkText
                )
                Text(
                  text = "متابعة يوميات الطفل، الوجبات، والتواصل",
                  fontSize = 12.sp,
                  color = MutedText
                )
              }
            }

            // Expanded Parent Area: Glowing action buttons + Forms
            AnimatedVisibility(
              visible = selectedRole == UserRole.PARENT,
              enter = fadeIn() + expandVertically(),
              exit = fadeOut() + shrinkVertically()
            ) {
              Column(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(top = 16.dp)
              ) {
                // Two Glowing Toggle Buttons: [تسجيل الدخول] و [إنشاء حساب جديد]
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFFF1F5F9))
                    .padding(4.dp),
                  horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                  // Button: تسجيل الدخول
                  Box(
                    modifier = Modifier
                      .weight(1f)
                      .clip(RoundedCornerShape(12.dp))
                      .background(
                        if (parentTab == ParentAuthTab.LOGIN) {
                          Brush.horizontalGradient(listOf(SalsabeelBlue, Color(0xFF0284C7)))
                        } else {
                          Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent))
                        }
                      )
                      .clickable { parentTab = ParentAuthTab.LOGIN }
                      .padding(vertical = 10.dp)
                      .testTag("parent_tab_login"),
                    contentAlignment = Alignment.Center
                  ) {
                    Text(
                      text = "تسجيل الدخول",
                      fontSize = 14.sp,
                      fontWeight = FontWeight.Bold,
                      color = if (parentTab == ParentAuthTab.LOGIN) PureWhite else MutedText
                    )
                  }

                  // Button: إنشاء حساب جديد
                  Box(
                    modifier = Modifier
                      .weight(1f)
                      .clip(RoundedCornerShape(12.dp))
                      .background(
                        if (parentTab == ParentAuthTab.REGISTER) {
                          Brush.horizontalGradient(listOf(JoyPink, Color(0xFFE11D48)))
                        } else {
                          Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent))
                        }
                      )
                      .clickable { parentTab = ParentAuthTab.REGISTER }
                      .padding(vertical = 10.dp)
                      .testTag("parent_tab_register"),
                    contentAlignment = Alignment.Center
                  ) {
                    Text(
                      text = "إنشاء حساب جديد ✨",
                      fontSize = 14.sp,
                      fontWeight = FontWeight.Bold,
                      color = if (parentTab == ParentAuthTab.REGISTER) PureWhite else MutedText
                    )
                  }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // SUB-FORM 1: PARENT LOGIN
                if (parentTab == ParentAuthTab.LOGIN) {
                  Column(modifier = Modifier.fillMaxWidth()) {
                    // Field 1: Email or Phone
                    OutlinedTextField(
                      value = parentLoginIdentifier,
                      onValueChange = { parentLoginIdentifier = it },
                      label = { Text("البريد الإلكتروني أو رقم الهاتف") },
                      placeholder = { Text("مثال: 0550123456 أو parent@mail.com") },
                      leadingIcon = {
                        Icon(imageVector = Icons.Default.Person, contentDescription = null, tint = SalsabeelBlue)
                      },
                      singleLine = true,
                      shape = RoundedCornerShape(14.dp),
                      modifier = Modifier
                        .fillMaxWidth()
                        .testTag("parent_login_identifier"),
                      colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = SalsabeelBlue,
                        focusedLabelColor = SalsabeelBlue
                      )
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Field 2: Password
                    OutlinedTextField(
                      value = parentLoginPassword,
                      onValueChange = { parentLoginPassword = it },
                      label = { Text("كلمة المرور") },
                      leadingIcon = {
                        Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = SalsabeelBlue)
                      },
                      trailingIcon = {
                        IconButton(onClick = { parentLoginPasswordVisible = !parentLoginPasswordVisible }) {
                          Icon(
                            imageVector = if (parentLoginPasswordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                            contentDescription = "تبديل الرؤية"
                          )
                        }
                      },
                      visualTransformation = if (parentLoginPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                      keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                      singleLine = true,
                      shape = RoundedCornerShape(14.dp),
                      modifier = Modifier
                        .fillMaxWidth()
                        .testTag("parent_login_password"),
                      colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = SalsabeelBlue,
                        focusedLabelColor = SalsabeelBlue
                      )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Row: Remember Me & Forgot Password
                    Row(
                      modifier = Modifier.fillMaxWidth(),
                      horizontalArrangement = Arrangement.SpaceBetween,
                      verticalAlignment = Alignment.CenterVertically
                    ) {
                      Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable { parentRememberMe = !parentRememberMe }
                      ) {
                        Checkbox(
                          checked = parentRememberMe,
                          onCheckedChange = { parentRememberMe = it },
                          colors = CheckboxDefaults.colors(checkedColor = SalsabeelBlue)
                        )
                        Text(
                          text = "تذكّر حسابي 🔒",
                          fontSize = 12.sp,
                          color = DarkText,
                          fontWeight = FontWeight.Medium
                        )
                      }

                      TextButton(
                        onClick = {
                          showForgotPasswordDialog = true
                          forgotStatusMessage = ""
                          isOtpSent = false
                        },
                        modifier = Modifier.testTag("parent_forgot_password_btn")
                      ) {
                        Text(
                          text = "نسيت كلمة المرور؟",
                          fontSize = 12.sp,
                          color = JoyPinkDark,
                          fontWeight = FontWeight.Bold
                        )
                      }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Submit Button: Login
                    Button(
                      onClick = {
                        val user = if (parentLoginIdentifier.isNotBlank()) parentLoginIdentifier else "ولي الأمر الكريم"
                        onParentLoginSuccess(user)
                      },
                      shape = RoundedCornerShape(14.dp),
                      colors = ButtonDefaults.buttonColors(containerColor = SalsabeelBlue),
                      modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("parent_login_submit_btn")
                    ) {
                      Text("تسجيل الدخول كولي أمر ✨", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    }
                  }
                } else {
                  // SUB-FORM 2: PARENT REGISTER
                  Column(modifier = Modifier.fillMaxWidth()) {
                    // Field 1: Email
                    OutlinedTextField(
                      value = regEmail,
                      onValueChange = { regEmail = it },
                      label = { Text("البريد الإلكتروني") },
                      placeholder = { Text("parent@example.com") },
                      leadingIcon = {
                        Icon(imageVector = Icons.Default.Email, contentDescription = null, tint = JoyPink)
                      },
                      keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                      singleLine = true,
                      shape = RoundedCornerShape(14.dp),
                      modifier = Modifier
                        .fillMaxWidth()
                        .testTag("reg_email_field"),
                      colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = JoyPink,
                        focusedLabelColor = JoyPinkDark
                      )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Field 2: Phone number
                    OutlinedTextField(
                      value = regPhone,
                      onValueChange = { regPhone = it },
                      label = { Text("رقم الهاتف") },
                      placeholder = { Text("05XXXXXXXX") },
                      leadingIcon = {
                        Icon(imageVector = Icons.Default.Phone, contentDescription = null, tint = JoyPink)
                      },
                      keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                      singleLine = true,
                      shape = RoundedCornerShape(14.dp),
                      modifier = Modifier
                        .fillMaxWidth()
                        .testTag("reg_phone_field"),
                      colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = JoyPink,
                        focusedLabelColor = JoyPinkDark
                      )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Field 3: Password
                    OutlinedTextField(
                      value = regPassword,
                      onValueChange = { regPassword = it },
                      label = { Text("كلمة المرور") },
                      leadingIcon = {
                        Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = JoyPink)
                      },
                      visualTransformation = if (regPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                      keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                      singleLine = true,
                      shape = RoundedCornerShape(14.dp),
                      modifier = Modifier
                        .fillMaxWidth()
                        .testTag("reg_password_field"),
                      colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = JoyPink,
                        focusedLabelColor = JoyPinkDark
                      )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Field 4: Confirm Password
                    OutlinedTextField(
                      value = regConfirmPassword,
                      onValueChange = { regConfirmPassword = it },
                      label = { Text("تأكيد كلمة المرور") },
                      leadingIcon = {
                        Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = JoyPink)
                      },
                      trailingIcon = {
                        IconButton(onClick = { regPasswordVisible = !regPasswordVisible }) {
                          Icon(
                            imageVector = if (regPasswordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                            contentDescription = "تبديل الرؤية"
                          )
                        }
                      },
                      visualTransformation = if (regPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                      keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                      singleLine = true,
                      shape = RoundedCornerShape(14.dp),
                      modifier = Modifier
                        .fillMaxWidth()
                        .testTag("reg_confirm_password_field"),
                      colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = JoyPink,
                        focusedLabelColor = JoyPinkDark
                      )
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Submit Button: Register
                    Button(
                      onClick = {
                        val email = if (regEmail.isNotBlank()) regEmail else "ولي الأمر"
                        onParentLoginSuccess(email)
                      },
                      shape = RoundedCornerShape(14.dp),
                      colors = ButtonDefaults.buttonColors(containerColor = JoyPink),
                      modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("reg_submit_btn")
                    ) {
                      Text("إنشاء الحساب ومتابعة 🎈", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    }
                  }
                }
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // CARD 2: ADMIN CARD (Interactive Expanding Card)
        Card(
          shape = RoundedCornerShape(24.dp),
          colors = CardDefaults.cardColors(
            containerColor = if (selectedRole == UserRole.ADMIN) PureWhite else PureWhite.copy(alpha = 0.75f)
          ),
          elevation = CardDefaults.cardElevation(
            defaultElevation = if (selectedRole == UserRole.ADMIN) 6.dp else 2.dp
          ),
          modifier = Modifier
            .fillMaxWidth()
            .border(
              width = if (selectedRole == UserRole.ADMIN) 2.dp else 1.dp,
              color = if (selectedRole == UserRole.ADMIN) SproutGreenDark else Color(0xFFE2E8F0),
              shape = RoundedCornerShape(24.dp)
            )
            .animateContentSize()
            .testTag("admin_role_card")
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(18.dp)
          ) {
            // Header click area to expand/collapse
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .clickable { selectedRole = UserRole.ADMIN },
              verticalAlignment = Alignment.CenterVertically
            ) {
              Box(
                modifier = Modifier
                  .size(48.dp)
                  .clip(RoundedCornerShape(14.dp))
                  .background(
                    if (selectedRole == UserRole.ADMIN) SproutGreenLight else Color(0xFFF1F5F9)
                  ),
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  imageVector = Icons.Default.AdminPanelSettings,
                  contentDescription = null,
                  tint = if (selectedRole == UserRole.ADMIN) SproutGreenDark else MutedText,
                  modifier = Modifier.size(28.dp)
                )
              }

              Spacer(modifier = Modifier.width(14.dp))

              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = "حساب الإدارة والكادر التعليمي 👩‍🏫",
                  fontSize = 17.sp,
                  fontWeight = FontWeight.Bold,
                  color = if (selectedRole == UserRole.ADMIN) SproutGreenDark else DarkText
                )
                Text(
                  text = "تسجيل دخول المعلمات والإدارة المدرسية فقط",
                  fontSize = 12.sp,
                  color = MutedText
                )
              }
            }

            // Expanded Admin Area: Shows LOGIN ONLY (No Registration)
            AnimatedVisibility(
              visible = selectedRole == UserRole.ADMIN,
              enter = fadeIn() + expandVertically(),
              exit = fadeOut() + shrinkVertically()
            ) {
              Column(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(top = 16.dp)
              ) {
                // Info note
                Surface(
                  shape = RoundedCornerShape(10.dp),
                  color = SproutGreenLight,
                  modifier = Modifier.fillMaxWidth()
                ) {
                  Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Icon(
                      imageVector = Icons.Default.Lock,
                      contentDescription = null,
                      tint = SproutGreenDark,
                      modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                      text = "بوابة مخصصة ومحمية للكادر الإداري والتعليمي",
                      fontSize = 12.sp,
                      color = SproutGreenDark,
                      fontWeight = FontWeight.Medium
                    )
                  }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Field 1: Admin Username / Email
                OutlinedTextField(
                  value = adminUsername,
                  onValueChange = { adminUsername = it },
                  label = { Text("البريد الوظيفي أو اسم المستخدم") },
                  placeholder = { Text("admin@salsabeel.edu") },
                  leadingIcon = {
                    Icon(imageVector = Icons.Default.Person, contentDescription = null, tint = SproutGreenDark)
                  },
                  singleLine = true,
                  shape = RoundedCornerShape(14.dp),
                  modifier = Modifier
                    .fillMaxWidth()
                    .testTag("admin_login_username"),
                  colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = SproutGreenDark,
                    focusedLabelColor = SproutGreenDark
                  )
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Field 2: Admin Password
                OutlinedTextField(
                  value = adminPassword,
                  onValueChange = { adminPassword = it },
                  label = { Text("كلمة المرور الإدارية") },
                  leadingIcon = {
                    Icon(imageVector = Icons.Default.Key, contentDescription = null, tint = SproutGreenDark)
                  },
                  trailingIcon = {
                    IconButton(onClick = { adminPasswordVisible = !adminPasswordVisible }) {
                      Icon(
                        imageVector = if (adminPasswordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                        contentDescription = "تبديل الرؤية"
                      )
                    }
                  },
                  visualTransformation = if (adminPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                  keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                  singleLine = true,
                  shape = RoundedCornerShape(14.dp),
                  modifier = Modifier
                    .fillMaxWidth()
                    .testTag("admin_login_password"),
                  colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = SproutGreenDark,
                    focusedLabelColor = SproutGreenDark
                  )
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  modifier = Modifier.clickable { adminRememberMe = !adminRememberMe }
                ) {
                  Checkbox(
                    checked = adminRememberMe,
                    onCheckedChange = { adminRememberMe = it },
                    colors = CheckboxDefaults.colors(checkedColor = SproutGreenDark)
                  )
                  Text(
                    text = "تذكّر بيانات الدخول",
                    fontSize = 12.sp,
                    color = DarkText
                  )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Submit Button: Admin Login
                Button(
                  onClick = {
                    val staff = if (adminUsername.isNotBlank()) adminUsername else "إدارة الروضة"
                    onAdminLoginSuccess(staff)
                  },
                  shape = RoundedCornerShape(14.dp),
                  colors = ButtonDefaults.buttonColors(containerColor = SproutGreenDark),
                  modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("admin_login_submit_btn")
                ) {
                  Text("دخول بوابة الإدارة 🔐", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                }
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(28.dp))
      }
    }

    // FORGOT PASSWORD DIALOG WITH OTP SIMULATION
    if (showForgotPasswordDialog) {
      AlertDialog(
        onDismissRequest = { showForgotPasswordDialog = false },
        title = {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.Key,
              contentDescription = null,
              tint = JoyPink,
              modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "استعادة كلمة المرور",
              fontSize = 17.sp,
              fontWeight = FontWeight.Bold,
              color = SalsabeelBlueDark
            )
          }
        },
        text = {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .verticalScroll(rememberScrollState())
          ) {
            Text(
              text = "أدخل بريدك الإلكتروني المسجل، وسنرسل لك رمز تحقق مباشر لإنشاء كلمة مرور جديدة.",
              fontSize = 13.sp,
              color = MutedText,
              lineHeight = 18.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Email Field
            OutlinedTextField(
              value = forgotEmail,
              onValueChange = { forgotEmail = it },
              label = { Text("البريد الإلكتروني") },
              placeholder = { Text("parent@example.com") },
              singleLine = true,
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier
                .fillMaxWidth()
                .testTag("forgot_email_input"),
              colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = SalsabeelBlue,
                focusedLabelColor = SalsabeelBlue
              )
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Send Code Button
            Button(
              onClick = {
                val targetEmail = if (forgotEmail.isNotBlank()) forgotEmail else "parent@mail.com"
                simulatedOtpCode = "7492" // Realistic 4-digit code
                isOtpSent = true
                forgotStatusMessage = "📨 تم إرسال كود التحقق [7492] إلى $targetEmail بنجاح!"
                enteredOtp = "7492" // Auto-fill for convenience
              },
              shape = RoundedCornerShape(10.dp),
              colors = ButtonDefaults.buttonColors(containerColor = SalsabeelBlue),
              modifier = Modifier
                .fillMaxWidth()
                .testTag("send_otp_btn")
            ) {
              Text(
                text = if (isOtpSent) "إعادة إرسال الرمز 🔄" else "إرسال كود التحقق 📨",
                fontSize = 13.sp
              )
            }

            // OTP Status simulation banner
            if (forgotStatusMessage.isNotBlank()) {
              Spacer(modifier = Modifier.height(10.dp))
              Surface(
                shape = RoundedCornerShape(10.dp),
                color = SproutGreenLight,
                modifier = Modifier.fillMaxWidth()
              ) {
                Row(
                  modifier = Modifier.padding(10.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Icon(
                    imageVector = Icons.Default.MarkEmailRead,
                    contentDescription = null,
                    tint = SproutGreenDark,
                    modifier = Modifier.size(18.dp)
                  )
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(
                    text = forgotStatusMessage,
                    fontSize = 12.sp,
                    color = SproutGreenDark,
                    fontWeight = FontWeight.Bold
                  )
                }
              }
            }

            if (isOtpSent) {
              Spacer(modifier = Modifier.height(12.dp))

              // Field for entering the OTP code
              OutlinedTextField(
                value = enteredOtp,
                onValueChange = { enteredOtp = it },
                label = { Text("رمز التحقق (الكود)") },
                placeholder = { Text("أدخل الكود أو الصقه هنا") },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                  .fillMaxWidth()
                  .testTag("otp_code_input"),
                colors = OutlinedTextFieldDefaults.colors(
                  focusedBorderColor = SproutGreenDark,
                  focusedLabelColor = SproutGreenDark
                )
              )

              Spacer(modifier = Modifier.height(10.dp))

              // New Password Field
              OutlinedTextField(
                value = newPassword,
                onValueChange = { newPassword = it },
                label = { Text("كلمة المرور الجديدة") },
                visualTransformation = PasswordVisualTransformation(),
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                  .fillMaxWidth()
                  .testTag("new_password_input"),
                colors = OutlinedTextFieldDefaults.colors(
                  focusedBorderColor = SalsabeelBlue,
                  focusedLabelColor = SalsabeelBlue
                )
              )

              Spacer(modifier = Modifier.height(10.dp))

              // Confirm New Password
              OutlinedTextField(
                value = confirmNewPassword,
                onValueChange = { confirmNewPassword = it },
                label = { Text("تأكيد كلمة المرور الجديدة") },
                visualTransformation = PasswordVisualTransformation(),
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                  .fillMaxWidth()
                  .testTag("confirm_new_password_input"),
                colors = OutlinedTextFieldDefaults.colors(
                  focusedBorderColor = SalsabeelBlue,
                  focusedLabelColor = SalsabeelBlue
                )
              )
            }
          }
        },
        confirmButton = {
          if (isOtpSent) {
            Button(
              onClick = {
                showForgotPasswordDialog = false
                val email = if (forgotEmail.isNotBlank()) forgotEmail else "ولي الأمر"
                onParentLoginSuccess(email)
              },
              colors = ButtonDefaults.buttonColors(containerColor = JoyPink),
              modifier = Modifier.testTag("reset_password_confirm_btn")
            ) {
              Text("تحديث كلمة المرور والدخول ✨")
            }
          }
        },
        dismissButton = {
          TextButton(onClick = { showForgotPasswordDialog = false }) {
            Text("إلغاء")
          }
        }
      )
    }
  }
}
