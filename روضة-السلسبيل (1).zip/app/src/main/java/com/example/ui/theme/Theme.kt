package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val HarmonizedColorScheme = lightColorScheme(
  primary = SalsabeelBlue,
  onPrimary = PureWhite,
  primaryContainer = SalsabeelBlueLight,
  onPrimaryContainer = SalsabeelBlueDark,
  secondary = SproutGreen,
  onSecondary = PureWhite,
  secondaryContainer = SproutGreenLight,
  onSecondaryContainer = SproutGreenDark,
  tertiary = JoyPink,
  onTertiary = PureWhite,
  tertiaryContainer = JoyPinkLight,
  onTertiaryContainer = JoyPinkDark,
  background = WarmCanvas,
  surface = PureWhite,
  onBackground = DarkText,
  onSurface = DarkText
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit
) {
  MaterialTheme(
    colorScheme = HarmonizedColorScheme,
    typography = Typography,
    content = content
  )
}
