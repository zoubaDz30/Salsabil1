package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.ChildRegistration
import kotlinx.coroutines.flow.Flow

@Dao
interface RegistrationDao {
    @Query("SELECT * FROM child_registrations ORDER BY registrationDate DESC")
    fun getAllRegistrations(): Flow<List<ChildRegistration>>

    @Query("SELECT * FROM child_registrations WHERE id = :id")
    suspend fun getRegistrationById(id: String): ChildRegistration?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRegistration(registration: ChildRegistration)

    @Update
    suspend fun updateRegistration(registration: ChildRegistration)

    @Query("DELETE FROM child_registrations WHERE id = :id")
    suspend fun deleteRegistration(id: String)
}
