package com.example.data

import com.example.R

data class ActivityPhoto(
  val id: Int,
  val drawableRes: Int,
  val title: String,
  val category: String,
  val description: String
)

data class MealItem(
  val time: String,
  val title: String,
  val details: String,
  val iconEmoji: String
)

data class AnnouncementItem(
  val id: Int,
  val title: String,
  val date: String,
  val content: String,
  val isImportant: Boolean = false
)

data class ChildAttendance(
  val id: Int,
  val name: String,
  val group: String,
  var isPresent: Boolean = true
)

object KindergartenRepository {
  val photos = listOf(
    ActivityPhoto(
      id = 1,
      drawableRes = R.drawable.p1,
      title = "ركن الإبداع والرسم",
      category = "أنشطة فنية",
      description = "تنمية مهارات التلوين والتعبير الفني بأمان ومرح"
    ),
    ActivityPhoto(
      id = 2,
      drawableRes = R.drawable.p2,
      title = "حلقة القراءة والحكايات",
      category = "تطوير لغوي",
      description = "جلسات ممتعة لقصص الحروف والقيم الأخلاقية"
    ),
    ActivityPhoto(
      id = 3,
      drawableRes = R.drawable.p3,
      title = "ألعاب الذكاء والتركيب",
      category = "تفكير إبداعي",
      description = "مكعبات وتحديات تنمي التركيز وحل المشكلات"
    ),
    ActivityPhoto(
      id = 4,
      drawableRes = R.drawable.p4,
      title = "الألعاب الحركية والساحة",
      category = "نشاط بدني",
      description = "تمارين رياضية خفيفة وألعاب جماعية مبهجة"
    ),
    ActivityPhoto(
      id = 5,
      drawableRes = R.drawable.p5,
      title = "الاستكشاف والتجارب الصغيرة",
      category = "علوم مبسطة",
      description = "اكتشاف النباتات والألوان والأشكال بالطبيعة"
    ),
    ActivityPhoto(
      id = 6,
      drawableRes = R.drawable.p6,
      title = "حفلات النجاح والمناسبات",
      category = "احتفالات",
      description = "تكريم الأطفال ومشاركتهم الفرحة والتشجيع المستمر"
    ),
    ActivityPhoto(
      id = 7,
      drawableRes = R.drawable.p7,
      title = "نشاطات التعاون والمشاركة",
      category = "مهارات اجتماعية",
      description = "بناء روح الفريق والمحبة بين براعم الروضة"
    ),
    ActivityPhoto(
      id = 8,
      drawableRes = R.drawable.p8,
      title = "ركن المطبخ الصحي والوجبات",
      category = "تغذية وصحة",
      description = "تعليم آداب المائدة وتناول الطعام الصحي الطازج"
    ),
    ActivityPhoto(
      id = 9,
      drawableRes = R.drawable.p9,
      title = "عالم الأرقام والألوان",
      category = "حساب ذهني",
      description = "تعلم مبكر ومرح لمفاهيم العد والأشكال الهندسية"
    ),
    ActivityPhoto(
      id = 10,
      drawableRes = R.drawable.pp10,
      title = "الأناشيد والمسرح الصغير",
      category = "موسيقى وإلقاء",
      description = "تعزيز الثقة بالنفس والطلاقة التعبيرية أمام الزملاء"
    ),
    ActivityPhoto(
      id = 11,
      drawableRes = R.drawable.pp11,
      title = "جولات التعلم الممتعة",
      category = "أنشطة تفاعلية",
      description = "لحظات مليئة بالضحكات والذكريات الجميلة لأطفالنا"
    )
  )

  val todayMeals = listOf(
    MealItem("09:00 ص", "وجبة الإفطار الصحي", "حليب طازج مع حبوب الشوفان والفواكه المقطعة وخبز التوست بالجبن", "🥛"),
    MealItem("11:30 ص", "سناك خفيف وطاقة", "تفاح مقطع وموز مع بسكويت الشوفان الصحي", "🍎"),
    MealItem("01:30 م", "وجبة الغداء المتوازنة", "شوربة خضار غنية، أرز بالخضار وقطع الدجاج المشوي المطهو بعناية", "🍲")
  )

  val announcements = listOf(
    AnnouncementItem(
      id = 1,
      title = "فتح باب التسجيل للفصل الدراسي الجديد 🎉",
      date = "اليوم",
      content = "نرحب باستقبال براعمنا الجدد في روضة السلسبيل. المقاعد محدودة لضمان أقصى رعاية واهتمام بكل طفل.",
      isImportant = true
    ),
    AnnouncementItem(
      id = 2,
      title = "يوم الألوان والمرح للأطفال 🎨",
      date = "الخميس القادم",
      content = "فعالية خاصة لارتداء الألوان المفضلة والمشاركة في جدارية الرسم الإبداعي في فناء الروضة.",
      isImportant = false
    ),
    AnnouncementItem(
      id = 3,
      title = "الكشف الصحي الدوري للأسنان والنمو 🩺",
      date = "الأسبوع المقبل",
      content = "زيارة دورية من الفريق الصحي المعتمد للاطمئنان على صحة أسنان أطفالنا وسلامتهم.",
      isImportant = false
    )
  )

  val sampleChildren = listOf(
    ChildAttendance(1, "محمد أحمد الفاسي", "فصل الفراشات (3-4 سنوات)", true),
    ChildAttendance(2, "سارة عمر التميمي", "فصل العصافير (4-5 سنوات)", true),
    ChildAttendance(3, "يوسف عبد الله الكعبي", "فصل النجوم (5-6 سنوات)", true),
    ChildAttendance(4, "مريم حسن البلوشي", "فصل الفراشات (3-4 سنوات)", false),
    ChildAttendance(5, "زين الدين خالد", "فصل العصافير (4-5 سنوات)", true),
    ChildAttendance(6, "نور سامي العلي", "فصل النجوم (5-6 سنوات)", true)
  )
}
