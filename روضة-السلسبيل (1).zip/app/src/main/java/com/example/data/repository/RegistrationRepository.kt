package com.example.data.repository

import com.example.data.local.RegistrationDao
import com.example.data.model.ChildRegistration
import kotlinx.coroutines.flow.Flow

class RegistrationRepository(private val registrationDao: RegistrationDao) {
    val allRegistrations: Flow<List<ChildRegistration>> = registrationDao.getAllRegistrations()

    suspend fun insert(registration: ChildRegistration) {
        registrationDao.insertRegistration(registration)
    }

    suspend fun update(registration: ChildRegistration) {
        registrationDao.updateRegistration(registration)
    }

    suspend fun delete(id: String) {
        registrationDao.deleteRegistration(id)
    }

    suspend fun getById(id: String): ChildRegistration? {
        return registrationDao.getRegistrationById(id)
    }
}
