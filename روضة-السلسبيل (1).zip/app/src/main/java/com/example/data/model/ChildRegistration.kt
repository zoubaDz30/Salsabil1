package com.example.data.model

import android.net.Uri
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "child_registrations")
data class ChildRegistration(
  @PrimaryKey
  val id: String = "REG-${System.currentTimeMillis() % 100000}",
  // Fold 1: Child info
  var childFullName: String = "",
  var gender: String = "ذكر",
  var birthDateAndPlace: String = "",
  var age: String = "",
  var educationalLevel: String = "أصاغر (2-3 سنوات)",
  var homeAddress: String = "",
  var childPhotoUri: Uri? = null,

  // Fold 1: Parents info
  var fatherName: String = "",
  var fatherPhone: String = "",
  var motherName: String = "",
  var motherPhone: String = "",
  var idCardPhotoUri: Uri? = null,

  // Fold 2: Emergency Contact
  var emergencyContactName: String = "",
  var emergencyContactRelation: String = "عم",
  var emergencyContactPhone: String = "",

  // Fold 3: Health Info
  var hasChronicDisease: Boolean = false,
  var chronicDiseaseDetails: String = "",
  var hasAllergy: Boolean = false,
  var allergyDetails: String = "",
  var takesRegularMedicine: Boolean = false,
  var medicineDetails: String = "",
  var hasFoodAllergy: Boolean = false,
  var foodAllergyDetails: String = "",
  var hadSeizures: Boolean = false,
  var seizuresDetails: String = "",
  var bloodGroup: String = "غير معروفة",
  var otherHealthNotes: String = "",

  // Fold 4: Notes & Signature
  var guardianName: String = "",
  var guardianSignature: String = "",
  var registrationDate: String = "",
  var isSubmittedToAdmin: Boolean = false,

  // Status and Admin Interaction
  var status: String = REGISTRATION_STATUS_PENDING,
  var adminFeedback: String = ""
)

const val REGISTRATION_STATUS_PENDING = "قيد المراجعة"
const val REGISTRATION_STATUS_ACCEPTED = "تم قبول طلب التسجيل"
const val REGISTRATION_STATUS_ERROR = "خطأ أو نقصان في التسجيل"

val EducationalLevels = listOf(
  "أصاغر (2-3 سنوات)",
  "تمهيدي (3-4 سنوات)",
  "تحضيري (5-6 سنوات)"
)

val BloodGroupList = listOf(
  "غير معروفة",
  "O+",
  "O-",
  "A+",
  "A-",
  "B+",
  "B-",
  "AB+",
  "AB-"
)

val FamilyRelations = listOf(
  "عم",
  "عمة",
  "خال",
  "خالة",
  "جد",
  "جدة",
  "أخ كبير",
  "أخت كبيرة",
  "قريب آخر"
)
