package com.example.util

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.R
import com.example.data.model.ChildRegistration
import java.io.File
import java.io.FileOutputStream

object PdfRegistrationExporter {

  fun generateAndSharePdf(context: Context, data: ChildRegistration) {
    try {
      val pdfDocument = PdfDocument()
      // Standard A4 dimensions at 72 dpi: 595 x 842 points
      val pageWidth = 595
      val pageHeight = 842
      val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
      val page = pdfDocument.startPage(pageInfo)
      val canvas: Canvas = page.canvas

      val paint = Paint().apply {
        isAntiAlias = true
      }

      // Background soft warm tint
      canvas.drawColor(Color.WHITE)

      // Outer Decorative Border (Salsabeel Blue & Sprout Green)
      paint.style = Paint.Style.STROKE
      paint.strokeWidth = 3f
      paint.color = Color.rgb(0, 112, 208) // Salsabeel Blue
      val borderRect = RectF(20f, 20f, pageWidth - 20f, pageHeight - 20f)
      canvas.drawRoundRect(borderRect, 14f, 14f, paint)

      paint.strokeWidth = 1f
      paint.color = Color.rgb(107, 184, 16) // Sprout Green
      canvas.drawRoundRect(RectF(24f, 24f, pageWidth - 24f, pageHeight - 24f), 12f, 12f, paint)

      // Header: Kindergarten Logo & Details
      try {
        val logoBitmap = BitmapFactory.decodeResource(context.resources, R.drawable.logo)
        if (logoBitmap != null) {
          val scaledLogo = Bitmap.createScaledBitmap(logoBitmap, 64, 48, true)
          canvas.drawBitmap(scaledLogo, pageWidth - 95f, 32f, paint)
        }
      } catch (_: Exception) {}

      // Header Texts
      paint.style = Paint.Style.FILL
      paint.textAlign = Paint.Align.RIGHT
      paint.textSize = 18f
      paint.isFakeBoldText = true
      paint.color = Color.rgb(0, 85, 160)
      canvas.drawText("روضة السلسبيل", pageWidth - 105f, 50f, paint)

      paint.textSize = 10f
      paint.isFakeBoldText = false
      paint.color = Color.rgb(71, 85, 105)
      canvas.drawText("نغرس القيم .. ننمي المستقبل", pageWidth - 105f, 66f, paint)
      canvas.drawText("ورقلة - حي بور الهايشة خلف المتوسطة | هاتف: 0668069662", pageWidth - 105f, 80f, paint)

      // Form Title Box
      paint.style = Paint.Style.FILL
      paint.color = Color.rgb(240, 249, 255) // Azure tint
      val titleRect = RectF(pageWidth / 2f - 130f, 100f, pageWidth / 2f + 130f, 136f)
      canvas.drawRoundRect(titleRect, 10f, 10f, paint)

      paint.style = Paint.Style.STROKE
      paint.strokeWidth = 1.5f
      paint.color = Color.rgb(240, 93, 154) // Joy Pink
      canvas.drawRoundRect(titleRect, 10f, 10f, paint)

      paint.style = Paint.Style.FILL
      paint.textAlign = Paint.Align.CENTER
      paint.textSize = 15f
      paint.isFakeBoldText = true
      paint.color = Color.rgb(0, 85, 160)
      canvas.drawText("استمارة معلومات الطفل (${data.id})", pageWidth / 2f, 124f, paint)

      var currentY = 160f

      // Section 1: بيانات الطفل (Child Details)
      drawSectionHeader(canvas, paint, "1. معلومات الطفل", currentY, pageWidth)
      currentY += 22f
      currentY = drawDataRow(canvas, paint, "اسم ولقب الطفل:", data.childFullName.ifBlank { "—" }, "الجنس:", data.gender.ifBlank { "—" }, currentY, pageWidth)
      currentY = drawDataRow(canvas, paint, "العمر:", data.age.ifBlank { "—" }, "المستوى الدراسي:", data.educationalLevel, currentY, pageWidth)
      currentY = drawDataRow(canvas, paint, "تاريخ ومكان الميلاد:", data.birthDateAndPlace.ifBlank { "—" }, "عنوان الإقامة:", data.homeAddress.ifBlank { "—" }, currentY, pageWidth)

      currentY += 10f

      // Section 2: بيانات الوالدين (Parents Details)
      drawSectionHeader(canvas, paint, "2. معلومات الوالدين", currentY, pageWidth)
      currentY += 22f
      currentY = drawDataRow(canvas, paint, "اسم ولقب الأب:", data.fatherName.ifBlank { "—" }, "رقم هاتف الأب:", data.fatherPhone.ifBlank { "—" }, currentY, pageWidth)
      currentY = drawDataRow(canvas, paint, "اسم ولقب الأم:", data.motherName.ifBlank { "—" }, "رقم هاتف الأم:", data.motherPhone.ifBlank { "—" }, currentY, pageWidth)

      currentY += 10f

      // Section 3: شخص للطوارئ (Emergency Contact)
      drawSectionHeader(canvas, paint, "3. شخص من العائلة للتواصل عند الضرورة", currentY, pageWidth)
      currentY += 22f
      currentY = drawDataRow(canvas, paint, "اسم فرد العائلة:", data.emergencyContactName.ifBlank { "—" }, "صلة القرابة:", data.emergencyContactRelation, currentY, pageWidth)
      currentY = drawDataRow(canvas, paint, "رقم هاتف الطوارئ:", data.emergencyContactPhone.ifBlank { "—" }, "", "", currentY, pageWidth)

      currentY += 10f

      // Section 4: المعلومات الصحية (Health Details)
      drawSectionHeader(canvas, paint, "4. المعلومات الصحية للطفل", currentY, pageWidth)
      currentY += 22f
      val chronic = if (data.hasChronicDisease) "نعم (${data.chronicDiseaseDetails})" else "لا"
      val allergy = if (data.hasAllergy) "نعم (${data.allergyDetails})" else "لا"
      currentY = drawDataRow(canvas, paint, "مرض مزمن:", chronic, "نوع الحساسية:", allergy, currentY, pageWidth)

      val medicine = if (data.takesRegularMedicine) "نعم (${data.medicineDetails})" else "لا"
      val food = if (data.hasFoodAllergy) "نعم (${data.foodAllergyDetails})" else "لا"
      currentY = drawDataRow(canvas, paint, "دواء بانتظام:", medicine, "حساسية أطعمة:", food, currentY, pageWidth)

      val seizures = if (data.hadSeizures) "نعم (${data.seizuresDetails})" else "لا"
      currentY = drawDataRow(canvas, paint, "تشنجات أو نوبات:", seizures, "فصيلة الدم:", data.bloodGroup, currentY, pageWidth)

      if (data.otherHealthNotes.isNotBlank()) {
        currentY = drawDataRow(canvas, paint, "ملاحظات صحية أخرى:", data.otherHealthNotes, "", "", currentY, pageWidth)
      }

      currentY += 14f

      // Section 5: إقرار ولي الأمر والتوقيع
      paint.style = Paint.Style.FILL
      paint.color = Color.rgb(254, 252, 232) // Warm soft cream
      val noticeRect = RectF(35f, currentY, pageWidth - 35f, currentY + 54f)
      canvas.drawRoundRect(noticeRect, 8f, 8f, paint)

      paint.textAlign = Paint.Align.RIGHT
      paint.textSize = 9.5f
      paint.color = Color.rgb(71, 85, 105)
      paint.isFakeBoldText = false
      canvas.drawText("ملاحظة مهمة: يرجى من ولي الأمر إبلاغ إدارة الروضة بأي معلومة صحية أو خاصة بالطفل قد تساعدنا على ضمان سلامته.", pageWidth - 45f, currentY + 22f, paint)
      canvas.drawText("تعاونكم معنا يساعدنا على رعاية أطفالكم بأفضل شكل .. معاً من أجل مستقبل أفضل لأطفالنا.", pageWidth - 45f, currentY + 40f, paint)

      currentY += 72f

      // Signature area
      paint.textSize = 11f
      paint.isFakeBoldText = true
      paint.color = Color.rgb(15, 23, 42)
      canvas.drawText("اسم ولي الأمر: ${data.guardianName.ifBlank { data.fatherName.ifBlank { "ولي الأمر" } }}", pageWidth - 50f, currentY, paint)
      canvas.drawText("تاريخ التسجيل: ${data.registrationDate.ifBlank { "اليوم" }}", 220f, currentY, paint)
      canvas.drawText("الإمضاء / المصادقة: ${data.guardianSignature.ifBlank { "معتمد إلكترونياً" }}", 130f, currentY + 24f, paint)

      // Footer
      paint.style = Paint.Style.STROKE
      paint.strokeWidth = 0.5f
      paint.color = Color.rgb(203, 213, 225)
      canvas.drawLine(35f, pageHeight - 45f, pageWidth - 35f, pageHeight - 45f, paint)

      paint.style = Paint.Style.FILL
      paint.textAlign = Paint.Align.CENTER
      paint.textSize = 9f
      paint.color = Color.rgb(100, 116, 139)
      paint.isFakeBoldText = false
      canvas.drawText("روضة السلسبيل - استمارة تسجيل رسمية رقم: ${data.id} - تم التوليد بنجاح", pageWidth / 2f, pageHeight - 32f, paint)

      pdfDocument.finishPage(page)

      // Save to external/cache files dir
      val pdfFileName = "استمارة_تسجيل_${data.childFullName.replace(" ", "_").ifBlank { "طفل" }}_${data.id}.pdf"
      val pdfFile = File(context.cacheDir, pdfFileName)
      val outputStream = FileOutputStream(pdfFile)
      pdfDocument.writeTo(outputStream)
      outputStream.flush()
      outputStream.close()
      pdfDocument.close()

      // Share or open via FileProvider
      val fileUri: Uri = FileProvider.getUriForFile(
        context,
        "${context.packageName}.fileprovider",
        pdfFile
      )

      val intent = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(fileUri, "application/pdf")
        flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK
      }

      val chooser = Intent.createChooser(intent, "فتح أو تحميل الاستمارة بصيغة PDF").apply {
        flags = Intent.FLAG_ACTIVITY_NEW_TASK
      }
      context.startActivity(chooser)
      Toast.makeText(context, "تم توليد وتحميل استمارة الـ PDF بنجاح 📄", Toast.LENGTH_LONG).show()

    } catch (e: Exception) {
      e.printStackTrace()
      Toast.makeText(context, "تعذر إنشاء ملف PDF: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
    }
  }

  private fun drawSectionHeader(canvas: Canvas, paint: Paint, title: String, y: Float, pageWidth: Int) {
    paint.style = Paint.Style.FILL
    paint.color = Color.rgb(241, 245, 249) // light slate
    canvas.drawRoundRect(RectF(35f, y, pageWidth - 35f, y + 20f), 4f, 4f, paint)

    paint.textAlign = Paint.Align.RIGHT
    paint.textSize = 11.5f
    paint.isFakeBoldText = true
    paint.color = Color.rgb(0, 85, 160) // Salsabeel dark blue
    canvas.drawText(title, pageWidth - 45f, y + 14f, paint)
  }

  private fun drawDataRow(
    canvas: Canvas,
    paint: Paint,
    label1: String,
    val1: String,
    label2: String,
    val2: String,
    y: Float,
    pageWidth: Int
  ): Float {
    paint.style = Paint.Style.FILL
    paint.textAlign = Paint.Align.RIGHT
    paint.textSize = 10f

    // Right Column
    paint.isFakeBoldText = true
    paint.color = Color.rgb(71, 85, 105)
    canvas.drawText(label1, pageWidth - 45f, y, paint)

    paint.isFakeBoldText = false
    paint.color = Color.rgb(15, 23, 42)
    canvas.drawText(val1, pageWidth - 145f, y, paint)

    // Left Column (if present)
    if (label2.isNotBlank()) {
      paint.isFakeBoldText = true
      paint.color = Color.rgb(71, 85, 105)
      canvas.drawText(label2, pageWidth / 2f - 20f, y, paint)

      paint.isFakeBoldText = false
      paint.color = Color.rgb(15, 23, 42)
      canvas.drawText(val2, pageWidth / 2f - 110f, y, paint)
    }

    return y + 17f
  }
}
