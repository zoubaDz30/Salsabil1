package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("روضة السلسبيل", appName)
  }

  @Test
  fun `verify child registration model defaults`() {
    val reg = com.example.data.model.ChildRegistration()
    org.junit.Assert.assertTrue(reg.id.startsWith("REG-"))
    org.junit.Assert.assertEquals("غير معروفة", reg.bloodGroup)
    org.junit.Assert.assertFalse(reg.isSubmittedToAdmin)
    org.junit.Assert.assertTrue(com.example.data.model.EducationalLevels.isNotEmpty())
    org.junit.Assert.assertTrue(com.example.data.model.BloodGroupList.contains("O+"))
  }
}
